source("API.r")
library(data.table)
library(ggplot2)
library(skimr)
library(ggcorrplot)
library(GGally)
library(forecast)
library(lubridate)
library(urca)

ArrangeTrainData <- function(code){
  raw_data <- read.csv("ProjectRawData.csv")
  raw_data <- data.table(raw_data)
  subm_url = 'http://46.101.163.177'
  u_name = "Group8"
  p_word = "aBbYZj795YeGEupS"
  submit_now = FALSE
  token = get_token(username=u_name, password=p_word, url=subm_url)
  data = get_data(token=token,url=subm_url)
  junedata <- data[event_date > '2021-05-31']
  raw_data[, "event_date" := as.Date(event_date)]
  raw_data <- rbindlist(list(raw_data, junedata), use.names = TRUE)
  raw_data <- raw_data[event_date >= '2020-05-25']
  raw_data[, month := month(event_date, label = TRUE)]
  raw_data[, wday := wday(event_date, label = TRUE)]
  traindata <- raw_data[product_content_id == code]
  code=6676673
  traindata <- traindata[order(traindata),]
  traindata[,trend := 1:.N]
  #traindata <- traindata[event_date > "2021-05-27",]
  traindata <- traindata[event_date <= "2021-05-27",]
  
  return(traindata)
}

ArrangeTestData <- function(code){
  raw_data <- read.csv("ProjectRawData.csv")
  raw_data <- data.table(raw_data)
  subm_url = 'http://46.101.163.177'
  u_name = "Group8"
  p_word = "aBbYZj795YeGEupS"
  submit_now = FALSE
  token = token
  #token = get_token(username=u_name, password=p_word, url=subm_url)
  data = get_data(token=token,url=subm_url)
  junedata <- data[event_date > '2021-05-31']
  raw_data[, "event_date" := as.Date(event_date)]
  raw_data <- rbindlist(list(raw_data, junedata), use.names = TRUE)
  raw_data <- raw_data[event_date >= '2020-05-25']
  raw_data[, month := month(event_date, label = TRUE)]
  raw_data[, wday := wday(event_date, label = TRUE)]
  traindata <- raw_data[product_content_id == code]
  # code=6676673
  traindata <- traindata[order(traindata),]
  traindata[,trend := 1:.N]
  #testdata <- traindata[event_date > "2021-05-27",]
  #traindata <- traindata[event_date <= "2021-05-27",]
  
  return(traindata)
}
#x <- ArrangeTestData(73318567)

accu=function(actual,forecast){
  n=length(actual)
  error=actual-forecast
  mean=mean(actual)
  sd=sd(actual)
  CV=sd/mean
  FBias=sum(error)/sum(actual)
  MAPE=sum(abs(error/actual))/n
  RMSE=sqrt(sum(error^2)/n)
  MAD=sum(abs(error))/n
  MADP=sum(abs(error))/sum(abs(actual))
  WMAPE = sum((abs(error)/actual)*actual)/sum(actual)
  #WMAPE2 = MAD/mean
  l=data.frame(n,mean,sd,CV,FBias,MAPE,RMSE,MAD,MADP, WMAPE)
  return(l)
}
