## ----setup, include=FALSE-----------------------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(include = FALSE)


## ----message=FALSE, warning=FALSE, include=FALSE------------------------------------------------------------------------------------------------------------
library(data.table)
library(ggplot2)
library(skimr)
library(ggcorrplot)
library(GGally)
library(forecast)
library(lubridate)
library(urca)
library(readxl)
library(data.table)
library(zoo)
library(GGally)
library(colorspace)
library(ggplot2)
library(skimr)
library(ggcorrplot)
library(car)
library(fpp)
library(readr)
library(jsonlite)
library(httr)
library(fpp)
library(data.table)
library(tidyverse)
library(urca)
library(forecast)
library(GGally)
library(lubridate)
library(tsibble)
Sys.setlocale("LC_TIME", "English")


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
library(data.table)
library(ggplot2)
library(skimr)
library(ggcorrplot)
library(GGally)
library(forecast)
library(lubridate)
library(urca)
load("C:/Users/alpsr/Desktop/Project/Project Final/homework 4-5.RData")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(xiaomi$sold_count))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(xiaomi$sold_count, lag.max = 50)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(xiaomi_ts_week_dec)
summary(ur.kpss(xiaomi_ts_week_dec$random))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(xiaomi_ts_year_dec)
summary(ur.kpss(xiaomi_ts_year_dec$random))


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
acf(xiaomi_random, na.action = na.pass, lag.max = 50)
pacf(xiaomi_random, na.action = na.pass, lag.max = 50)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
summary(m3)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
checkresiduals(m3)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = Model1), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count - Model1))
acf(xiaomi$sold_count-xiaomi$Model1, na.action = na.pass)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggpairs(xiaomi[,c(4,18:20)])
# plot(xiaomi$price) # ok
# plot(xiaomi$visit_count) 
# plot(xiaomi$basket_count) # ok
# plot(xiaomi$favored_count)
# plot(xiaomi$category_sold) # not ok unusual behavior
# plot(xiaomi$category_basket)
# plot(xiaomi$category_visits)
# plot(xiaomi$category_favored) # ok
# plot(xiaomi$category_brand_sold)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
summary(m2)
checkresiduals(m2)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = Model2), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count - Model2))
acf(xiaomi$sold_count-xiaomi$Model2, na.action = na.pass)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
frame_xiaomi


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(fakir$sold_count))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(fakir$sold_count, lag.max = 50)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(fakir_ts_week_dec)
summary(ur.kpss(fakir_ts_week_dec$random))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(fakir_ts_year_dec)
summary(ur.kpss(fakir_ts_year_dec$random))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(fakir_random, na.action = na.pass, lag.max = 50)
pacf(fakir_random, na.action = na.pass, lag.max = 50)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
summary(m1_fakir)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
checkresiduals(m1_fakir)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = Model1), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count - Model1))
acf(fakir$sold_count-fakir$Model1, na.action = na.pass)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggpairs(fakir[,c(4,18:21)])
# plot(fakir$price) # ok
# plot(fakir$visit_count) 
# plot(fakir$basket_count) # ok
# plot(fakir$favored_count)
# plot(fakir$category_sold) # ok
# plot(fakir$category_basket)
# plot(fakir$category_visits)
# plot(fakir$category_favored) # ok
# plot(fakir$category_brand_sold)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
summary(m2_fakir)
checkresiduals(m2_fakir)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = Model2), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count - Model2))
acf(fakir$sold_count-fakir$Model2, na.action = na.pass)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
frame_fakir


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
tsdisplay((mont_ts_week))
acf(mont$sold_count, lag.max = 50)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(mont$sold_count, lag.max = 50)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(mont_ts_week_dec)
summary(ur.kpss(mont_ts_week_dec$random))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(mont_ts_year_dec)
summary(ur.kpss(mont_ts_year_dec$random))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(mont_random, na.action = na.pass, lag.max = 50)
pacf(mont_random, na.action = na.pass, lag.max = 50)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
summary(m1_mont)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
checkresiduals(m1_mont)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = Model1), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(mont, aes(x = event_date))+
  geom_point(aes(y = sold_count - Model1))
acf(mont$sold_count-mont$Model1, na.action = na.pass)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggpairs(mont[,c(4,18:21)])
# plot(fakir$price) # ok
# plot(fakir$visit_count) 
# plot(fakir$basket_count) # ok
# plot(fakir$favored_count)
# plot(fakir$category_sold) # ok
# plot(fakir$category_basket)
# plot(fakir$category_visits)
# plot(fakir$category_favored) # ok
# plot(fakir$category_brand_sold)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
summary(m2_mont)
checkresiduals(m2_mont)


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = Model2), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')


## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
ggplot(mont, aes(x = event_date))+
  geom_point(aes(y = sold_count - Model2))
acf(mont$sold_count-mont$Model2, na.action = na.pass)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
frame_mont
rm(list = ls())


## -----------------------------------------------------------------------------------------------------------------------------------------------------------

accu=function(actual,forecast){
  n=length(actual)
  error=actual-forecast
  mean=mean(actual)
  sd=sd(actual)
  CV=sd/mean
  FBias=sum(error)/sum(actual)
  MAPE=sum(abs(error/actual))/n
  RMSE=sqrt(sum(error^2)/n)
  MAD=sum(abs(error))/n
  MADP=sum(abs(error))/sum(abs(actual))
  WMAPE = sum((abs(error)/actual)*actual)/sum(actual)
  #WMAPE=MAD/mean
  l=data.frame(n,mean,sd,CV,FBias,MAPE,RMSE,MAD,MADP,WMAPE)
  return(l)
}

updated_data <- read.csv("updated_data.csv")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil <- updated_data %>%
  mutate(event_date=as.Date(event_date)) %>%
  arrange(event_date) %>%
  filter(product_content_id==4066298) %>%
  as.data.table()


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(bebek_mendil$sold_count, na.action = na.pass)
pacf(bebek_mendil$sold_count, na.action = na.pass)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(bebek_mendil, aes(x=event_date))+
  geom_line(aes(y=sold_count))+
  labs(title="Sales of Sleepy over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil_ts <- ts(bebek_mendil$sold_count, frequency = 7)
bebek_mendil_decomposed <- decompose(bebek_mendil_ts,type = "multiplicative")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(bebek_mendil_decomposed)

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil_decomposed$random %>%
  ur.kpss() %>%
  summary()


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
weekly_bebek_mendil <- bebek_mendil %>%
  group_by(yearweek(event_date)) %>%
  summarise(sold_count=mean(sold_count)) %>%
  rename(yearweek='yearweek(event_date)')


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(weekly_bebek_mendil, aes(x=yearweek,y=sold_count ))+
  geom_line()+
  labs(title="Average weekly sales of Sleepy over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(weekly_bebek_mendil$sold_count, na.action = na.pass)
pacf(weekly_bebek_mendil$sold_count, na.action = na.pass)



## -----------------------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil_weekly_ts <- ts(weekly_bebek_mendil$sold_count, frequency = 7)
bebek_mendil_decomposed_weekly <- decompose(bebek_mendil_weekly_ts, type = "additive")
plot(bebek_mendil_decomposed_weekly)

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil_decomposed_weekly$random %>%
  ur.kpss() %>%
  summary()


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
monthly_bebek_mendil <- bebek_mendil %>%
  group_by(yearmonth(event_date)) %>%
  summarise(sold_count=mean(sold_count)) %>%
  rename(month='yearmonth(event_date)')


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(monthly_bebek_mendil, aes(x=month,y=sold_count))+
  geom_line()+
  labs(title="Average monthly sales of Sleepy over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
random_bebek_mendil <- bebek_mendil_decomposed$random


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(random_bebek_mendil, na.action = na.pass)
pacf(random_bebek_mendil, na.action = na.pass)



## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(random_bebek_mendil, order = c(1,0,0))

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(random_bebek_mendil, order = c(2,0,0))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(random_bebek_mendil, order = c(3,0,0))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(random_bebek_mendil, order = c(0,0,1))



## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(random_bebek_mendil, order = c(2,0,1))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggpairs(bebek_mendil[,-c(1,2,5,7,10,12,13)])



## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(random_bebek_mendil, xreg = bebek_mendil$category_sold, order=c(2,0,1))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
auto.arima(random_bebek_mendil, xreg = bebek_mendil$category_sold)

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
auto.arima(random_bebek_mendil, xreg = bebek_mendil$category_favored)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
auto.arima(random_bebek_mendil, xreg = cbind(bebek_mendil$category_favored,bebek_mendil$category_sold))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
test_dates <- c(as.Date("2021-06-24"):as.Date("2021-06-30"))

for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- bebek_mendil[event_date<=current_date,]
  
  bebek_mendil_ts <- ts(past_data$sold_count, frequency = 7)
  bebek_mendil_decomposed <- decompose(bebek_mendil_ts,type = "multiplicative")
  model <- arima(bebek_mendil_decomposed$random,order = c(3,1,1),seasonal = c(0,0,1), xreg=past_data$category_sold)
  forecasted=predict(model,n.ahead = 2,newxreg = bebek_mendil[event_date==test_dates[i],"category_sold"])
  bebek_mendil[nrow(bebek_mendil)-length(test_dates)+i,Model1:=forecasted$pred[2]*bebek_mendil_decomposed$seasonal[(nrow(bebek_mendil)-length(test_dates)+i)%%7+7]*bebek_mendil_decomposed$trend[max(which(!is.na(bebek_mendil_decomposed$trend)))]]
}

m<-accu(bebek_mendil$sold_count[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))],bebek_mendil$Model1[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))])


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
m


## ---- warning=FALSE-----------------------------------------------------------------------------------------------------------------------------------------
ggplot(bebek_mendil,aes(x=event_date))+
  geom_line(aes(y=Model1), color="red")+
  xlim(as.Date("2021-06-24"),as.Date("2021-06-30"))+ #Update here
  geom_line(aes(y=sold_count))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
dis_fircasi <- updated_data %>%
  mutate(event_date=as.Date(event_date)) %>%
  arrange(event_date) %>%
  filter(product_content_id==32939029) %>%
  as.data.table()


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(dis_fircasi$sold_count, na.action = na.pass)
pacf(dis_fircasi$sold_count, na.action = na.pass)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(dis_fircasi, aes(x=event_date))+
  geom_line(aes(y=sold_count))+
  labs(title="Sales of Oral-B over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
dis_fircasi_ts <- ts(dis_fircasi$sold_count, frequency = 7)
dis_fircasi_decomposed <- decompose(dis_fircasi_ts,type = "multiplicative")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(dis_fircasi_decomposed)

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
dis_fircasi_decomposed$random %>%
  ur.kpss() %>%
  summary()


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
weekly_dis_fircasi <- dis_fircasi %>%
  group_by(yearweek(event_date)) %>%
  summarise(sold_count=mean(sold_count)) %>%
  rename(yearweek='yearweek(event_date)')


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(weekly_dis_fircasi, aes(x=yearweek,y=sold_count ))+
  geom_line()+
  labs(title="Average weekly sales of Sleepy over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(weekly_dis_fircasi$sold_count, na.action = na.pass)
pacf(weekly_dis_fircasi$sold_count, na.action = na.pass)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
dis_fircasi_weekly_ts <- ts(weekly_dis_fircasi$sold_count, frequency = 7)
dis_fircasi_decomposed_weekly <- decompose(dis_fircasi_weekly_ts, type = "multiplicative")
plot(dis_fircasi_decomposed_weekly)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
monthly_dis_fircasi <- dis_fircasi %>%
  group_by(yearmonth(event_date)) %>%
  summarise(sold_count=mean(sold_count)) %>%
  rename(month='yearmonth(event_date)')


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(monthly_dis_fircasi, aes(x=month,y=sold_count))+
  geom_line()+
  labs(title="Average monthly sales of Sleepy over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
dis_fircasi_random <- dis_fircasi_decomposed$random


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(dis_fircasi_random, na.action = na.pass)
pacf(dis_fircasi_random, na.action = na.pass)



## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(dis_fircasi_random, order=c(1,0,0))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(dis_fircasi_random, order=c(2,0,0))

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(dis_fircasi_random, order=c(1,0,1))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(dis_fircasi_random, order=c(2,0,1))

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(dis_fircasi_random, order=c(3,0,2))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggpairs(dis_fircasi[,-c(1,2,5,7,10,12,13)])


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(dis_fircasi_random, order=c(3,0,2), xreg = dis_fircasi$category_favored)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
auto.arima(dis_fircasi_random, xreg = dis_fircasi$category_favored)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
test_dates <- c(as.Date("2021-06-24"):as.Date("2021-06-30"))

for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- dis_fircasi[event_date<=current_date,]
  
  dis_fircasi_ts <- ts(past_data$sold_count, frequency = 7)
  dis_fircasi_decomposed <- decompose(dis_fircasi_ts,type = "multiplicative")
  model <- arima(dis_fircasi_decomposed$random,order = c(3,0,2), xreg=past_data$category_favored)
  forecasted=predict(model,n.ahead = 2,newxreg = dis_fircasi[event_date==test_dates[i],"category_favored"])
  dis_fircasi[nrow(dis_fircasi)-length(test_dates)+i,Model1:=forecasted$pred[2]*dis_fircasi_decomposed$seasonal[(nrow(dis_fircasi)-length(test_dates)+i)%%7+7]*dis_fircasi_decomposed$trend[max(which(!is.na(dis_fircasi_decomposed$trend)))]]
}

s<-accu(dis_fircasi$sold_count[(nrow(dis_fircasi)+1-length(test_dates)):(nrow(dis_fircasi))],dis_fircasi$Model1[(nrow(dis_fircasi)+1-length(test_dates)):(nrow(dis_fircasi))])


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
s


## ---- warning=FALSE-----------------------------------------------------------------------------------------------------------------------------------------
ggplot(dis_fircasi,aes(x=event_date))+
  geom_line(aes(y=Model1), color="red")+
  xlim(as.Date("2021-06-24"),as.Date("2021-06-30"))+ #Update here
  geom_line(aes(y=sold_count))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
yuz_temizleyici <- updated_data %>%
  mutate(event_date=as.Date(event_date)) %>%
  arrange(event_date) %>%
  filter(product_content_id==85004) %>%
  as.data.table()


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(yuz_temizleyici$sold_count, na.action = na.pass)
pacf(yuz_temizleyici$sold_count, na.action = na.pass)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(yuz_temizleyici, aes(x=event_date))+
  geom_line(aes(y=sold_count))+
  labs(title="Sales of La Roche over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
yuz_temizleyici_ts <- ts(yuz_temizleyici$sold_count, frequency = 15)
yuz_temizleyici_decomposed <- decompose(yuz_temizleyici_ts,type = "multiplicative")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(yuz_temizleyici_decomposed)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
weekly_yuz_temizleyici <- yuz_temizleyici %>%
  group_by(yearweek(event_date)) %>%
  summarise(sold_count=mean(sold_count)) %>%
  rename(yearweek='yearweek(event_date)')


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(weekly_yuz_temizleyici, aes(x=yearweek,y=sold_count ))+
  geom_line()+
  labs(title="Average weekly sales of Sleepy over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(weekly_yuz_temizleyici$sold_count, na.action = na.pass)
pacf(weekly_yuz_temizleyici$sold_count, na.action = na.pass)



## -----------------------------------------------------------------------------------------------------------------------------------------------------------
yuz_temizleyici_weekly_ts <- ts(weekly_yuz_temizleyici$sold_count, frequency = 9)
yuz_temizleyici_decomposed_weekly <- decompose(yuz_temizleyici_weekly_ts, type = "additive")
plot(yuz_temizleyici_decomposed_weekly)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
monthly_yuz_temizleyici <- yuz_temizleyici %>%
  group_by(yearmonth(event_date)) %>%
  summarise(sold_count=mean(sold_count)) %>%
  rename(month='yearmonth(event_date)')


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(monthly_yuz_temizleyici, aes(x=month,y=sold_count))+
  geom_line()+
  labs(title="Average monthly sales of Sleepy over time")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
yuz_temizleyici_random <- yuz_temizleyici_decomposed$random


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(yuz_temizleyici_random, order=c(1,0,0))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(yuz_temizleyici_random, order=c(0,0,1))

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(yuz_temizleyici_random, order=c(2,0,0))

## -----------------------------------------------------------------------------------------------------------------------------------------------------------
arima(yuz_temizleyici_random, order=c(1,0,2))


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
auto.arima(yuz_temizleyici_random)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggpairs(yuz_temizleyici[,-c(1,2,5,7,10,12,13)])


## ----warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
arima(yuz_temizleyici_random, order=c(2,0,3), xreg = yuz_temizleyici$category_favored)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
auto.arima(yuz_temizleyici_random, xreg = yuz_temizleyici$category_favored)


## ---- warning=FALSE-----------------------------------------------------------------------------------------------------------------------------------------
test_dates <- c(as.Date("2021-06-24"):as.Date("2021-06-30"))

for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- yuz_temizleyici[event_date<=current_date,]
  
  yuz_temizleyici_ts <- ts(past_data$sold_count, frequency = 15)
  yuz_temizleyici_decomposed <- decompose(yuz_temizleyici_ts,type = "multiplicative")
  model <- arima(yuz_temizleyici_decomposed$random,order = c(2,0,3), xreg=past_data$category_favored)
  forecasted=predict(model,n.ahead = 2,newxreg = yuz_temizleyici[event_date==test_dates[i],"category_favored"])
  yuz_temizleyici[nrow(yuz_temizleyici)-length(test_dates)+i,Model1:=forecasted$pred[2]*yuz_temizleyici_decomposed$seasonal[(nrow(yuz_temizleyici)-length(test_dates)+i)%%15+15]*yuz_temizleyici_decomposed$trend[max(which(!is.na(yuz_temizleyici_decomposed$trend)))]]
}

t<-accu(yuz_temizleyici$sold_count[(nrow(yuz_temizleyici)+1-length(test_dates)):(nrow(yuz_temizleyici))],yuz_temizleyici$Model1[(nrow(yuz_temizleyici)+1-length(test_dates)):(nrow(yuz_temizleyici))])


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
t


## ---- warning=FALSE-----------------------------------------------------------------------------------------------------------------------------------------
ggplot(yuz_temizleyici,aes(x=event_date))+
  geom_line(aes(y=Model1), color="red")+
  xlim(as.Date("2021-06-24"),as.Date("2021-06-30"))+ #Update here
  geom_line(aes(y=sold_count))


## ----pressure, echo=FALSE-----------------------------------------------------------------------------------------------------------------------------------

get_token <- function(username, password, url_site){
  
  post_body = list(username=username,password=password)
  post_url_string = paste0(url_site,'/token/')
  result = POST(post_url_string, body = post_body)
  
  # error handling (wrong credentials)
  if(result$status_code==400){
    print('Check your credentials')
    return(0)
  }
  else if (result$status_code==201){
    output = content(result)
    token = output$key
  }
  
  return(token)
}

get_data <- function(start_date='2020-03-20', token, url_site){
  
  post_body = list(start_date=start_date,username=username,password=password)
  post_url_string = paste0(url_site,'/dataset/')
  
  header = add_headers(c(Authorization=paste('Token',token,sep=' ')))
  result = GET(post_url_string, header, body = post_body)
  output = content(result)
  data = data.table::rbindlist(output)
  data[,event_date:=as.Date(event_date)]
  data = data[order(product_content_id,event_date)]
  return(data)
}


send_submission <- function(predictions, token, url_site, submit_now=F){
  
  format_check=check_format(predictions)
  if(!format_check){
    return(FALSE)
  }
  
  post_string="list("
  for(i in 1:nrow(predictions)){
    post_string=sprintf("%s'%s'=%s",post_string,predictions$product_content_id[i],predictions$forecast[i])
    if(i<nrow(predictions)){
      post_string=sprintf("%s,",post_string)
    } else {
      post_string=sprintf("%s)",post_string)
    }
  }
  
  submission = eval(parse(text=post_string))
  json_body = jsonlite::toJSON(submission, auto_unbox = TRUE)
  submission=list(submission=json_body)
  
  print(submission)
  # {"31515569":2.4,"32737302":2.4,"32939029":2.4,"4066298":2.4,"48740784":2.4,"6676673":2.4, "7061886":2.4, "73318567":2.4, "85004":2.4} 
  
  if(!submit_now){
    print("You did not submit.")
    return(FALSE)      
  }
  
  
  header = add_headers(c(Authorization=paste('Token',token,sep=' ')))
  post_url_string = paste0(url_site,'/submission/')
  result = POST(post_url_string, header, body=submission)
  
  if (result$status_code==201){
    print("Successfully submitted. Below you can see the details of your submission")
  } else {
    print("Could not submit. Please check the error message below, contact the assistant if needed.")
  }
  
  print(content(result))
  
}

check_format <- function(predictions){
  
  if(is.data.frame(predictions) | is.data.frame(predictions)){
    if(all(c('product_content_id','forecast') %in% names(predictions))){
      if(is.numeric(predictions$forecast)){
        print("Format OK")
        return(TRUE)
      } else {
        print("forecast information is not numeric")
        return(FALSE)                
      }
    } else {
      print("Wrong column names. Please provide 'product_content_id' and 'forecast' columns")
      return(FALSE)
    }
    
  } else {
    print("Wrong format. Please provide data.frame or data.table object")
    return(FALSE)
  }
  
}

# this part is main code
subm_url = 'http://46.101.163.177'

u_name = "Group8"
p_word = "aBbYZj795YeGEupS"
submit_now = FALSE

username = u_name
password = p_word

token = '84ea343ee6df0a64d2b63baaac94745d6f668072'

data = get_data(token=token,url=subm_url)
combine_data <- data[event_date > as.Date('2021-05-31')]

#predictions=unique(data[,list(product_content_id)])
#predictions[,forecast:=2.3]

#send_submission(predictions, token, url=subm_url, submit_now=F)

ProjectRawData <- read_csv("ProjectRawData.csv")

raw_data <- rbind(ProjectRawData ,combine_data)



## -----------------------------------------------------------------------------------------------------------------------------------------------------------
raw_data <- data.table(raw_data)
raw_data[, "event_date" := as.Date(event_date)]
raw_data <- raw_data[event_date >= '2020-05-25']
raw_data[, trend := 1:.N]
raw_data[, month := month(event_date, label = TRUE)]
raw_data[, wday := wday(event_date, label = TRUE)]
raw_data <- raw_data[order(event_date),]


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
data_leopar <- raw_data[product_content_id == 73318567] #leopar


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(data_leopar, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red")  + ggtitle("Trend of Leopard Skin Bikini Sales") + xlab("Date") + ylab("Sales")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(data_leopar$sold_count, main= "Daily Autocorrelation")
pacf(data_leopar$sold_count, main= "Daily Partial Autocorrelation") 


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
leopar <- na.omit(data_leopar)
ggplot(leopar, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red")  + ggtitle("Trend of Leopard Skin Bikini Sales N/A Omitted") + xlab("Date") + ylab("Sales")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(leopar$sold_count, main= "Daily Autocorrelation")
pacf(leopar$sold_count, main= "Daily Autocorrelation")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
leoparts <- ts(data_leopar$sold_count,freq=7)
data_mult<-decompose(leoparts,type="multiplicative")
random=data_mult$random
plot(data_mult)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_mult$seasonal[1:7], xlab = "Hour", ylab = "Multiplicative of Day", main = "Seasonal Component of Trend for Multiplicative")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=data_leopar[,list(m_sold = mean(sold_count,na.rm=T)), by="wday"]
mean_sold


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_mult$random) 
summary(unt_test)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
leoparts <- ts(data_leopar$sold_count,freq=7)
data_add<-decompose(leoparts,type="additive")
random=data_add$random
plot(data_add)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_add$seasonal[1:7], xlab = "Hour", ylab = "Additive of Day", main = "Seasonal Component of Trend for Additive")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=data_leopar[,list(m_sold = mean(sold_count,na.rm=T)), by="wday"]
mean_sold


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_add$random) 
summary(unt_test)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(random, na.action = na.pass, main= "Detrend's Autocorrelation")
pacf(random, na.action = na.pass, main= "Detrend's Autocorrelation")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(5,0,0))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(0,0,5))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(5,0,5))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
modelf <- arima(random, order=c(5,0,4))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(4,0,4))
print(model)


## ---- warning=FALSE-----------------------------------------------------------------------------------------------------------------------------------------
leopar <- data_leopar
leopar <- leopar[, random := data_add$random]
numeric_data <- leopar
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
leopar <- leopar[,favored_count_lag := shift(favored_count, 2)]
leopar <- leopar[,basket_count_lag := shift(basket_count, 2)]
leopar <- leopar[,visit_count_lag := shift(visit_count, 2)]

numeric_data <- leopar
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)



## ----message=FALSE, warning=FALSE---------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind( leopar$basket_count_lag) # can add more if any other regressors exist
   model1 <- arima(leopar$random, order = c(5,0,4), xreg = reg_matrix)
  summary(model1)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------

model_fitted <- leopar$random - residuals(model1)
leopar <- cbind(leopar, data_add$seasonal, data_add$trend, model_fitted)
leopar <-leopar[,predict1 := data_add$seasonal + data_add$trend + model_fitted] 

model_fitted_2 <- leopar$random - residuals(modelf)
leopar <- cbind(leopar, model_fitted_2)
leopar <-leopar[,predictonlyar := data_add$seasonal + data_add$trend + model_fitted_2] 


ggplot(leopar, aes(x=event_date)) + 
  geom_line(aes(y = sold_count, color = "Sales")) + 
  geom_line(aes(y = predict1, color="Prediction with Arima")) + 
    geom_line(aes(y = predictonlyar, color = "Prediction with Arima + Regressors")) + ggtitle ("Actual vs Predicted Data")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind( leopar$basket_count_lag, leopar$visit_count_lag) # can add more if any other regressors exist

   model2 <- arima(leopar$random,order = c(5,0,4), xreg = reg_matrix)
  summary(model2)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
accu=function(actual,forecast){
  n=length(actual)
  error=actual-forecast
  mean=mean(actual)
  sd=sd(actual)
  CV=sd/mean
  FBias=sum(error)/sum(actual)
  MAPE=sum(abs(error/actual))/n
  RMSE=sqrt(sum(error^2)/n)
  MAD=sum(abs(error))/n
  MADP=sum(abs(error))/sum(abs(actual))
  WMAPE=MAD/mean
  l=data.frame(n,mean,sd,CV,FBias,MAPE,RMSE,MAD,MADP,WMAPE)
  return(l)
}


## -----------------------------------------------------------------------------------------------------------------------------------------------------------

train_start=as.Date('2021-01-23')
test_start=as.Date('2021-06-24')
test_end=as.Date('2021-06-30')

test_dates=seq(test_start,test_end,by='day')

for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- leopar[event_date<=current_date,]
    
    leopar_ts <- ts(past_data$sold_count, frequency = 7)  
    leopar_decomposed <- decompose(leopar_ts, type="additive")
    model <- arima(leopar_decomposed$random,order = c(5,0,4),xreg = past_data$basket_count_lag)
    
    forecasted=predict(model,n.ahead = 2,newxreg = leopar[event_date==test_dates[i],basket_count_lag])
    leopar[nrow(leopar)-length(test_dates)+i-2, Model_reg := forecasted$pred[2]+leopar_decomposed$seasonal[(nrow(leopar)-length(test_dates)+i-2)%%7+7]+leopar_decomposed$trend[max(which(!is.na(leopar_decomposed$trend)))]]
  }
  m_with_reg<-accu(leopar$sold_count[(nrow(leopar)-1-length(test_dates)):(nrow(leopar)-2)],(leopar$Model_reg[(nrow(leopar)-1-length(test_dates)):(nrow(leopar)-2)]))  
 


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- leopar[event_date<=current_date,]
    
    leopar_ts <- ts(past_data$sold_count, frequency = 7)  
    leopar_decomposed <- decompose(leopar_ts, type="additive")
    model <- arima(leopar_decomposed$random,order = c(5,0,4))
    
    forecasted=predict(model,n.ahead = 2)
    leopar[nrow(leopar)-length(test_dates)+i-2, Model_nolag := forecasted$pred[2]+leopar_decomposed$seasonal[(nrow(leopar)-length(test_dates)+i-2)%%7+7]+leopar_decomposed$trend[max(which(!is.na(leopar_decomposed$trend)))]]
  }
  m_only_arima<-accu(leopar$sold_count[(nrow(leopar)-1-length(test_dates)):(nrow(leopar)-2)],(leopar$Model_nolag[(nrow(leopar)-1-length(test_dates)):(nrow(leopar)-2)]))  


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
rbind(m_with_reg,m_only_arima)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
data_siyah <- raw_data[product_content_id == 32737302] 


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(data_siyah, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red") + ggtitle("Trend of Black Bikini Sales") + xlab("Date") + ylab("Sales")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(data_siyah$sold_count, main= "Daily Autocorrelation")
siyah <- data_siyah


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
siyahts <- ts(siyah$sold_count,freq=7)
data_mult<-decompose(siyahts,type="multiplicative")
random=data_mult$random
plot(data_mult)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_mult$seasonal[1:7], xlab = "Hour", ylab = "Multiplicative of Day", main = "Seasonal Component of Trend for Multiplicative")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=siyah[,list(mean_sold = mean(sold_count,na.rm=T)), by="wday"]
mean_sold


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_mult$random) 
summary(unt_test)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
siyahts <- ts(siyah$sold_count,freq=7)
data_add<-decompose(siyahts,type="additive")
random=data_add$random
plot(data_add)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_add$seasonal[1:7], xlab = "Hour", ylab = "Additive of Day", main = "Seasonal Component of Trend for Additive")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=siyah[,list(m_sold = mean(sold_count,na.rm=T)), by="wday"]
mean_sold


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_add$random) 
summary(unt_test)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(random, na.action = na.pass, main= "Detrend's Autocorrelation")
pacf(random, na.action = na.pass, main= "Detrend's Autocorrelation")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(6,0,0))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
modelf <- arima(random, order=c(0,0,3))
print(modelf)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(6,0,3))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(0,0,4))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(0,0,2))
print(model)


## ---- warning=FALSE-----------------------------------------------------------------------------------------------------------------------------------------
siyah <- siyah[, random := data_add$random]
numeric_data <- siyah
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)




## -----------------------------------------------------------------------------------------------------------------------------------------------------------
siyah <- siyah[,category_sold_lag := shift(category_sold, 2)]
siyah <- siyah[,basket_count_lag := shift(basket_count, 2)]
siyah <- siyah[,visit_count_lag := shift(visit_count, 2)]

numeric_data <- siyah
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)



## -----------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind( siyah$basket_count_lag) # can add more if any other regressors exist
   model1 <- arima(siyah$random,order = c(0,0,3), xreg = reg_matrix)
  summary(model1)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------

model_fitted <- siyah$random - residuals(model1)
siyah <- cbind(siyah, data_add$seasonal, data_add$trend, model_fitted)
siyah <-siyah[,predictarima := data_add$seasonal + data_add$trend + model_fitted  ] 

model_fitted_2 <- siyah$random - residuals(modelf)
siyah <- cbind(siyah, model_fitted_2)
siyah <-siyah[,predictonlyar := data_add$seasonal + data_add$trend + model_fitted_2] 

ggplot(siyah, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red") + 
  geom_line(aes(y = predictarima), color="blue") + ggtitle("Trend of Black Bikini Sales") + xlab("Date") + ylab("Sales")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind( siyah$visit_count_lag) 

   model2 <- arima(siyah$random,order = c(0,0,3), xreg = reg_matrix)
  summary(model2)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind( siyah$category_sold_lag) 

   model3 <- arima(siyah$random,order = c(0,0,3), xreg = reg_matrix)
  summary(model3)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------

train_start=as.Date('2021-01-23')
test_start=as.Date('2021-06-24')
test_end=as.Date('2021-06-30')

test_dates=seq(test_start,test_end,by='day')

for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- siyah[event_date<=current_date,]
    
    siyah_ts <- ts(past_data$sold_count, frequency = 7)  
    siyah_decomposed <- decompose(siyah_ts, type="additive")
    model <- arima(siyah_decomposed$random,order = c(0,0,3),xreg = past_data$visit_count_lag)
    
    forecasted=predict(model,n.ahead = 2,newxreg = siyah[event_date==test_dates[i],visit_count_lag])
    siyah[nrow(siyah)-length(test_dates)+i-2, Model_reg := forecasted$pred[2]+siyah_decomposed$seasonal[(nrow(siyah)-length(test_dates)+i-2)%%7+7]+siyah_decomposed$trend[max(which(!is.na(siyah_decomposed$trend)))]]
  }
  m_with_lag<-accu(siyah$sold_count[(nrow(siyah)-1-length(test_dates)):(nrow(siyah)-2)],(siyah$Model_reg[(nrow(siyah)-1-length(test_dates)):(nrow(siyah)-2)]))  
 


## -----------------------------------------------------------------------------------------------------------------------------------------------------------

for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- siyah[event_date<=current_date,]
    
    siyah_ts <- ts(past_data$sold_count, frequency = 7)  
    siyah_decomposed <- decompose(siyah_ts, type="additive")
    model <- arima(siyah_decomposed$random,order = c(0,0,3))
    
    forecasted=predict(model,n.ahead = 2)
    siyah[nrow(siyah)-length(test_dates)+i-2, Model_no_reg := forecasted$pred[2]+siyah_decomposed$seasonal[(nrow(siyah)-length(test_dates)+i-2)%%7+7]+siyah_decomposed$trend[max(which(!is.na(siyah_decomposed$trend)))]]
  }
  m_without_lag<-accu(siyah$sold_count[(nrow(siyah)-1-length(test_dates)):(nrow(siyah)-2)],(siyah$Model_no_reg[(nrow(siyah)-1-length(test_dates)):(nrow(siyah)-2)]))  
  


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
data_tayt <- raw_data[product_content_id == 31515569]


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(data_tayt, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red") + ggtitle("Trend of Leggings Sales") + xlab("Date") + ylab("Sales")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(data_tayt$sold_count, main= "Daily Autocorrelation")
pacf(data_tayt$sold_count, main= "Daily Autocorrelation")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
tayt <- data_tayt
taytts <- ts(tayt$sold_count,freq=7)
data_mult<-decompose(taytts,type="multiplicative")
random=data_mult$random
plot(data_mult)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_mult$seasonal[1:7], xlab = "Hour", ylab = "Multiplicative of Day", main = "Seasonal Component of Trend for Multiplicative")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=tayt[,list(mean_sold = mean(sold_count,na.rm=T)), by="wday"]
mean_sold


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_mult$random) 
summary(unt_test)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
taytts <- ts(tayt$sold_count,freq=7)
data_add<-decompose(taytts,type="additive")
random=data_add$random
plot(data_add)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_add$seasonal[1:7], xlab = "Hour", ylab = "Additive of Day", main = "Seasonal Component of Trend for Additive")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_add$random) 
summary(unt_test)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
taytts <- ts(tayt$sold_count,freq=16)
data_add_2<-decompose(taytts,type="additive")
plot(data_add_2)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_add_2$seasonal[1:16], xlab = "Hour", ylab = "Additive of Day", main = "Seasonal Component of Trend for Additive")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_add_2$random) 
summary(unt_test)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
acf(random, na.action = na.pass, main= "Detrend's Autocorrelation")
pacf(random, na.action = na.pass, main= "Detrend's Autocorrelation")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(4,0,0))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(0,0,4))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(4,0,4))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(3,0,4))
print(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
modelf <- arima(random, order=c(4,0,3))
print(modelf)


## ---- warning=FALSE-----------------------------------------------------------------------------------------------------------------------------------------
tayt <- tayt[, random := data_add$random]
numeric_data <- tayt
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)




## -----------------------------------------------------------------------------------------------------------------------------------------------------------
tayt <- tayt[,category_sold_lag := shift(category_sold, 2)]
tayt <- tayt[,basket_count_lag := shift(basket_count, 2)]


numeric_data <- tayt
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)



## -----------------------------------------------------------------------------------------------------------------------------------------------------------

reg_matrix=cbind( tayt$basket_count_lag) # can add more if any other regressors exist
   model1 <- arima(tayt$random,order = c(4,0,3), xreg = reg_matrix)
  summary(model)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind(tayt$category_sold_lag) 

   model1 <- arima(tayt$random,order = c(4,0,3), xreg = reg_matrix)
  summary(model1)


## -----------------------------------------------------------------------------------------------------------------------------------------------------------

model_fitted <- tayt$random - residuals(model1)
tayt <- cbind(tayt, data_add$seasonal, data_add$trend, model_fitted)
tayt <-tayt[,predictarima := data_add$seasonal + data_add$trend + model_fitted  ] 

model_fitted_2 <- tayt$random - residuals(modelf)
tayt <- cbind(tayt,model_fitted_2)
tayt <-tayt[,predictarima_no_reg := data_add$seasonal + data_add$trend + model_fitted_2  ] 

ggplot(tayt, aes(x=event_date)) + 
  geom_line(aes(y = sold_count, color = "sold_count")) + 
  geom_line(aes(y = predictarima, color = "only_arima_prediction")) + 
   geom_line(aes(y = predictarima_no_reg, color = "arima_with_lag")) + ggtitle("Trend of Leggings Sales") + xlab("Date") + ylab("Sales")


## -----------------------------------------------------------------------------------------------------------------------------------------------------------

train_start=as.Date('2021-01-23')
test_start=as.Date('2021-06-23')
test_end=as.Date('2021-06-30')

test_dates=seq(test_start,test_end,by='day')

for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- tayt[event_date<=current_date,]
    
    tayt_ts <- ts(past_data$sold_count, frequency = 7)  
    tayt_decomposed <- decompose(tayt_ts, type="additive")
    model <- arima(tayt_decomposed$random,order = c(4,0,3),xreg = past_data$basket_count_lag)
    
    forecasted=predict(model,n.ahead = 2,newxreg = tayt[event_date==test_dates[i],basket_count_lag])
    tayt[nrow(tayt)-length(test_dates)+i-2, Model_reg := forecasted$pred[2]+tayt_decomposed$seasonal[(nrow(tayt)-length(test_dates)+i-2)%%7+7]+tayt_decomposed$trend[max(which(!is.na(tayt_decomposed$trend)))]]
  }
  m_with_7<-accu(tayt$sold_count[(nrow(tayt)-1-length(test_dates)):(nrow(tayt)-2)],(tayt$Model_reg[(nrow(tayt)-1-length(test_dates)):(nrow(tayt)-2)]))  
 


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- tayt[event_date<=current_date,]
    
    tayt_ts <- ts(past_data$sold_count, frequency =7)  
    tayt_decomposed <- decompose(tayt_ts, type="additive")
    model <- arima(tayt_decomposed$random,order = c(4,0,3))
    
    forecasted=predict(model,n.ahead = 2)
    tayt[nrow(tayt)-length(test_dates)+i-2, Model_noreg := forecasted$pred[2]+tayt_decomposed$seasonal[(nrow(tayt)-length(test_dates)+i-2)%%7+7]+tayt_decomposed$trend[max(which(!is.na(tayt_decomposed$trend)))]]
  }
  m_with_no_reg<-accu(tayt$sold_count[(nrow(tayt)-1-length(test_dates)):(nrow(tayt)-2)],(tayt$Model_noreg[(nrow(tayt)-1-length(test_dates)):(nrow(tayt)-2)]))  
 


## -----------------------------------------------------------------------------------------------------------------------------------------------------------
rbind(m_with_7,m_with_no_reg)

