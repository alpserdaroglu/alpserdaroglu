## ----setup, include=FALSE------------------------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- warning=FALSE, message=FALSE---------------------------------------------------------------------------------------------------------------------------
require(jsonlite)
require(httr)
require(data.table)
library(tidyverse)
library(urca)
library(forecast)
library(GGally)
library(lubridate)
library(data.table)
library(ggplot2)
library(skimr)
library(ggcorrplot)
library(forecast)
library(lubridate)
library(urca)
Sys.setlocale("LC_TIME", "English")


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
load("C:/Users/alpsr/Desktop/Project/Project Final/xiaomi_environment.RData")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
# ggplot(xiaomi) +
#   geom_boxplot(aes(y = sold_count))
ggplot(xiaomi, aes(x = event_date)) +
  geom_line(aes(y = sold_count))


## ----message=FALSE-------------------------------------------------------------------------------------------------------------------------------------------
ggplot(xiaomi) +
  geom_histogram(aes(x = sold_count))


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(xiaomi$sold_count, lag.max = 40) #Autoregressive signature sinusodial/ expo decreasing --> maybe seasonality
pacf(xiaomi$sold_count, lag.max = 40)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggpairs(xiaomi[,c(4,17:21)]) # visit count lag, price, basket lag, cat sold lag, favored_count lag, cat favored lag

# summary(m11)
# AIC(m11)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(m12)
AIC(m12)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(m14c)
AIC(m14c)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
# ARIMA on residuals
summary(ur.kpss(random1, use.lag = 30))
tsdisplay(random1)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(m14b)
AIC(m14b)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
# ARIMA on residuals
summary(ur.kpss(random2, use.lag = 30))
tsdisplay(random2)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(d18)
checkresiduals(d18)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(xiaomi$sold_count-xiaomi$Model1Fitted))
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model1Fitted, color = "fitted"))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(e115)
checkresiduals(e115)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(xiaomi$sold_count-xiaomi$Model2Fitted))
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model2Fitted, color = "fitted"))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(xiaomi_sarima)
checkresiduals(xiaomi_sarima)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model3Fitted, color = "fitted"))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
plot(xiaomi_ts_dec)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(r113)
checkresiduals(r113)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(xiaomi$sold_count-xiaomi$Model4Fitted))
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model4Fitted, color = "fitted"))


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
eval


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
rm(list = ls())
load("C:/Users/alpsr/Desktop/Project/Project Final/Fakir_environment.RData")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
# ggplot(fakir) +
#   geom_boxplot(aes(y = sold_count))
ggplot(fakir, aes(x = event_date)) +
  geom_line(aes(y = sold_count))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggplot(fakir) +
  geom_histogram(aes(x = sold_count))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
acf(fakir$sold_count, lag.max = 40) 
pacf(fakir$sold_count, lag.max = 40)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggpairs(fakir[,c(4,17:21)]) # visit count lag, price, basket lag, cat sold lag, favored_count lag, cat favored lag


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(m11)
AIC(m11)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
summary(ur.kpss(random1, use.lag = 32))
tsdisplay(random1)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(m12)
AIC(m12)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(m14c)
AIC(m14c)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(ur.kpss(random2, use.lag = 30))
tsdisplay(random2)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(d27)
checkresiduals(d27)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(fakir$sold_count-fakir$Model1Fitted))

ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model1Fitted, color = "fitted"))


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
# ARIMA on residuals
summary(e110)
checkresiduals(e110)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(fakir$sold_count-fakir$Model2Fitted))
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model2Fitted, color = "fitted"))


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
summary(autoarima2)
checkresiduals(autoarima2)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(fakir$sold_count-fakir$Model3Fitted))
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model2Fitted, color = "fitted"))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(fakir_sarima)

checkresiduals(fakir_sarima)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model4Fitted, color = "fitted"))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(fakir_sarima2)
checkresiduals(fakir_sarima2)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(fakir_sarima2$residuals)
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model5Fitted, color = "fitted"))


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
eval


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
rm(list = ls())
load("C:/Users/alpsr/Desktop/Project/Project Final/mont_environment.RData")


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggplot(mont, aes(x = event_date)) +
  geom_line(aes(y = sold_count))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggplot(mont) +
  geom_histogram(aes(x = sold_count))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggpairs(mont[,c(4,17:21)])


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(m11)
AIC(m11)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(m12)
AIC(m12)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
checkresiduals(m11)
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model1Fitted, color = "fitted"))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
# ARIMA on residuals
summary(ur.kpss(random1, use.lag = 30))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(d36)
checkresiduals(d36)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(mont$sold_count-mont$Model2Fitted))
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model2Fitted, color = "fitted"))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(autoarima1)
checkresiduals(autoarima1)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
tsdisplay(ts(mont$sold_count-mont$Model3Fitted))
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model3Fitted, color = "fitted"))


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
summary(mont_sarimax) # regressoes basekt count and category sold


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
checkresiduals(mont_sarimax)


## ----message=FALSE, warning=FALSE----------------------------------------------------------------------------------------------------------------------------
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model4Fitted, color = "fitted"))


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
eval
rm(list = ls())


## ---- include=FALSE------------------------------------------------------------------------------------------------------------------------------------------
get_token <- function(username, password, url_site){
  
  post_body = list(username=username,password=password)
  post_url_string = paste0(url_site,'/token/')
  result = POST(post_url_string, body = post_body)
  
  # error handling (wrong credentials)
  if(result$status_code==400){
    print('Check your credentials')
    return(0)
  }
  else if (result$status_code==201){
    output = content(result)
    token = output$key
  }
  
  return(token)
}

get_data <- function(start_date='2020-03-20', token, url_site){
  
  post_body = list(start_date=start_date,username=username,password=password)
  post_url_string = paste0(url_site,'/dataset/')
  
  header = add_headers(c(Authorization=paste('Token',token,sep=' ')))
  result = GET(post_url_string, header, body = post_body)
  output = content(result)
  data = data.table::rbindlist(output)
  data[,event_date:=as.Date(event_date)]
  data = data[order(product_content_id,event_date)]
  return(data)
}


send_submission <- function(predictions, token, url_site, submit_now=F){
  
  format_check=check_format(predictions)
  if(!format_check){
    return(FALSE)
  }
  
  post_string="list("
  for(i in 1:nrow(predictions)){
    post_string=sprintf("%s'%s'=%s",post_string,predictions$product_content_id[i],predictions$forecast[i])
    if(i<nrow(predictions)){
      post_string=sprintf("%s,",post_string)
    } else {
      post_string=sprintf("%s)",post_string)
    }
  }
  
  submission = eval(parse(text=post_string))
  json_body = jsonlite::toJSON(submission, auto_unbox = TRUE)
  submission=list(submission=json_body)
  
  print(submission)
  # {"31515569":2.4,"32737302":2.4,"32939029":2.4,"4066298":2.4,"48740784":2.4,"6676673":2.4, "7061886":2.4, "73318567":2.4, "85004":2.4} 
  
  if(!submit_now){
    print("You did not submit.")
    return(FALSE)      
  }
  
  
  header = add_headers(c(Authorization=paste('Token',token,sep=' ')))
  post_url_string = paste0(url_site,'/submission/')
  result = POST(post_url_string, header, body=submission)
  
  if (result$status_code==201){
    print("Successfully submitted. Below you can see the details of your submission")
  } else {
    print("Could not submit. Please check the error message below, contact the assistant if needed.")
  }
  
  print(content(result))
  
}

check_format <- function(predictions){
  
  if(is.data.frame(predictions) | is.data.frame(predictions)){
    if(all(c('product_content_id','forecast') %in% names(predictions))){
      if(is.numeric(predictions$forecast)){
        print("Format OK")
        return(TRUE)
      } else {
        print("forecast information is not numeric")
        return(FALSE)                
      }
    } else {
      print("Wrong column names. Please provide 'product_content_id' and 'forecast' columns")
      return(FALSE)
    }
    
  } else {
    print("Wrong format. Please provide data.frame or data.table object")
    return(FALSE)
  }
  
}

# this part is main code
subm_url = 'http://46.101.163.177'

u_name = "Group8"
p_word = "aBbYZj795YeGEupS"
submit_now = FALSE

username = u_name
password = p_word

##----

token = get_token(username=u_name, password=p_word, url=subm_url)

accu=function(actual,forecast){
  n=length(actual)
  error=actual-forecast
  mean=mean(actual)
  sd=sd(actual)
  CV=sd/mean
  FBias=sum(error)/sum(actual)
  MAPE=sum(abs(error/actual))/n
  RMSE=sqrt(sum(error^2)/n)
  MAD=sum(abs(error))/n
  MADP=sum(abs(error))/sum(abs(actual))
  WMAPE = sum((abs(error)/actual)*actual)/sum(actual)
  #WMAPE=MAD/mean
  l=data.frame(n,mean,sd,CV,FBias,MAPE,RMSE,MAD,MADP,WMAPE)
  return(l)
}


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
data = get_data(token=token,url=subm_url)

rawdata <- read.csv("C:/Users/alpsr/Desktop/Project/Project Final/ProjectRawData.csv")

rawdata <- na.omit(rawdata,event_date)

fetched_data_filtered <- data %>%
  mutate(event_date=as.Date(event_date)) %>% 
  filter(event_date>"2021-05-31") %>%
  select(colnames(rawdata)) %>%
  arrange(event_date)

updated_data <- rbind.data.frame(fetched_data_filtered,rawdata)

updated_data <- updated_data %>%
  filter(event_date<="2021-06-11") # we selected "2021-05-28"-"2021-06-11" as our test period


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
dis_fircasi <- updated_data %>%
  mutate(event_date=as.Date(event_date)) %>%
  arrange(event_date) %>%
  filter(product_content_id==32939029) 



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(dis_fircasi, aes(x=event_date))+
  geom_line(aes(y=sold_count)) +
  labs(title="Sales of Oral B over time")



## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
dis_fircasi[,log_sold:=log(sold_count)]


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(dis_fircasi$sold_count, na.action = na.pass)
pacf(dis_fircasi$sold_count, na.action = na.pass)



## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
ggplot(dis_fircasi, aes(x=event_date))+
  geom_line(aes(y=log_sold))+
  labs(title="log(Sales) of Oral B over time")
w <- which(dis_fircasi$log_sold==0)
dis_fircasi$log_sold[w] <- mean(c(dis_fircasi$log_sold[31],dis_fircasi$log_sold[34]))


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(dis_fircasi$price,dis_fircasi$log_sold)


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
test_dates <- c(as.Date("2021-05-28"):as.Date("2021-06-11")) #Update here
for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- dis_fircasi[event_date<=current_date,]
  
  dis_fircasi_ts <- ts(past_data$log_sold, frequency = 7)  
  dis_fircasi_decomposed <- decompose(dis_fircasi_ts, type="additive")
  model <- arima(dis_fircasi_decomposed$random,order = c(2,1,2),seasonal = list(order=c(1,0,0)),xreg = past_data$price)
  forecasted=predict(model,n.ahead = 2,newxreg = dis_fircasi[event_date==test_dates[i],price])
  dis_fircasi[nrow(dis_fircasi)-length(test_dates)+i, Model1 := forecasted$pred[2]+dis_fircasi_decomposed$seasonal[(nrow(dis_fircasi)-length(test_dates)+i)%%7+7]+dis_fircasi_decomposed$trend[max(which(!is.na(dis_fircasi_decomposed$trend)))]]
}
m<-accu(dis_fircasi$sold_count[(nrow(dis_fircasi)+1-length(test_dates)):(nrow(dis_fircasi))],exp(dis_fircasi$Model1[(nrow(dis_fircasi)+1-length(test_dates)):(nrow(dis_fircasi))]))

 


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- dis_fircasi[event_date<=current_date,]
    
    dis_fircasi_ts <- ts(past_data$log_sold, frequency = 7)  
    dis_fircasi_decomposed <- decompose(dis_fircasi_ts, type="additive")
    model <- arima(dis_fircasi_decomposed$random,order = c(1,0,0),seasonal = list(order=c(1,0,0)),xreg = past_data$price)
    forecasted=predict(model,n.ahead = 2,newxreg = dis_fircasi[event_date==test_dates[i],price])
    dis_fircasi[nrow(dis_fircasi)-length(test_dates)+i, Model2 := forecasted$pred[2]+dis_fircasi_decomposed$seasonal[(nrow(dis_fircasi)-length(test_dates)+i)%%7+7]+dis_fircasi_decomposed$trend[max(which(!is.na(dis_fircasi_decomposed$trend)))]]
  }
  m2<-accu(dis_fircasi$sold_count[(nrow(dis_fircasi)+1-length(test_dates)):(nrow(dis_fircasi))],exp(dis_fircasi$Model2[(nrow(dis_fircasi)+1-length(test_dates)):(nrow(dis_fircasi))]))  
 



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
dis_fircasi[,pred1:=exp(Model1)]
dis_fircasi[,pred2:=exp(Model2)]
  


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil <- updated_data %>%
  mutate(event_date=as.Date(event_date)) %>%
  arrange(event_date) %>%
  filter(product_content_id==4066298)



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(bebek_mendil, aes(x=event_date))+
  geom_line(aes(y=sold_count))+
  labs(title="Sales of Sleepy over time")



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(bebek_mendil$sold_count, na.action = na.pass)
pacf(bebek_mendil$sold_count, na.action = na.pass)


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil[,log_sold:=log(sold_count)]
bebek_mendil[,lagged:=lag(log_sold)]
bebek_mendil[,popular_period:=ifelse(ty_visits>130000000,1,0)] 
ggplot(bebek_mendil, aes(x=event_date))+
  geom_line(aes(y=log_sold))+
  labs(title="log(Sales) of Sleepy over time")



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil$log_sold %>%
  ur.kpss() %>%
  summary()


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(bebek_mendil$price,bebek_mendil$log_sold)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
test_dates <- c(as.Date("2021-05-28"):as.Date("2021-06-11")) #Update here

for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- bebek_mendil[event_date<=current_date,]
  fitted_arima=arima(past_data$log_sold, xreg = past_data$price,order=c(0,1,5))
  forecasted=predict(fitted_arima,newxreg = bebek_mendil[event_date==test_dates[i],price],n.ahead = 2)
  bebek_mendil[nrow(bebek_mendil)-length(test_dates)+i, Model1 := forecasted$pred[2]]
}

s<-accu(bebek_mendil$sold_count[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))],exp(bebek_mendil$Model1[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))]))



## ----eval=FALSE----------------------------------------------------------------------------------------------------------------------------------------------
## lm(log_sold~lagged,bebek_mendil)
## lm(log_sold~lagged+price,bebek_mendil)
## lm(log_sold~lagged+price+ty_visits,bebek_mendil)
## lm(log_sold~lagged+price+ty_visits+as.factor(month(event_date)),bebek_mendil)
## lm(log_sold~lagged+price+ty_visits+as.factor(month(event_date))+as.factor(weekdays(event_date)))
## lm(log_sold~lagged+price+as.factor(month(event_date))+as.factor(weekdays(event_date)))


## ----eval=FALSE----------------------------------------------------------------------------------------------------------------------------------------------
## lm(log_sold~lagged+price+as.factor(month(event_date))+as.factor(weekdays(event_date)))


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
test_dates <- c(as.Date("2021-05-28"):as.Date("2021-06-11")) #Update here
fmla <- "log_sold~lagged+price+as.factor(month(event_date))+as.factor(weekdays(event_date))"
for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- bebek_mendil[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residual, order = c(1,0,0))
  forecasted=predict(fitted_lm,bebek_mendil[event_date == test_dates[i],])
  bebek_mendil[nrow(bebek_mendil)-length(test_dates)+i, Model2 := forecasted+forecast(rm,h=2)$mean[2]]
}

s2 <-accu(bebek_mendil$sold_count[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))],exp(bebek_mendil$Model2[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))])) 




## ------------------------------------------------------------------------------------------------------------------------------------------------------------
fmla2 <- "log_sold~lagged+price+as.factor(month(event_date))+as.factor(weekdays(event_date))+as.factor(popular_period)"
  for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- bebek_mendil[event_date<=current_date,]
    fitted_lm=lm(as.formula(fmla2),past_data)
    rm <- arima(fitted_lm$residual, order = c(1,0,0))
    forecasted=predict(fitted_lm,bebek_mendil[event_date == test_dates[i],])
    bebek_mendil[nrow(bebek_mendil)-length(test_dates)+i, Model3 := forecasted+forecast(rm,h=2)$mean[2]]
  }
  
  s3 <-accu(bebek_mendil$sold_count[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))],exp(bebek_mendil$Model3[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))]))
  


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
  for(i in 1:length(test_dates)){

    current_date=test_dates[i]-2

    past_data <- bebek_mendil[event_date<=current_date,]
    fitted_arima=arima(past_data$log_sold, xreg = cbind(past_data$price,past_data$popular_period),order=c(0,1,5))
    forecasted=predict(fitted_arima,newxreg = cbind(bebek_mendil[event_date==test_dates[i],price],bebek_mendil[event_date==test_dates[i],popular_period]),n.ahead = 2)
    bebek_mendil[nrow(bebek_mendil)-length(test_dates)+i, Model4 := forecasted$pred[2]]
  }

    s4<-accu(bebek_mendil$sold_count[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))],exp(bebek_mendil$Model4[(nrow(bebek_mendil)+1-length(test_dates)):(nrow(bebek_mendil))]))

    
    


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
bebek_mendil[,pred1:=exp(Model1)]
bebek_mendil[,pred2:=exp(Model2)]
bebek_mendil[,pred3:=exp(Model3)]
bebek_mendil[,pred4:=exp(Model4)]



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
yuz_temizleyici <- updated_data %>%
  mutate(event_date=as.Date(event_date)) %>%
  arrange(event_date) %>%
  filter(product_content_id==85004)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

ggplot(yuz_temizleyici, aes(x=event_date))+
  geom_line(aes(y=sold_count))+
  labs(title="Sales of La Roche over time")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(yuz_temizleyici$sold_count, na.action = na.pass)


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
yuz_temizleyici[,log_sold:=log(sold_count)]

## ------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(yuz_temizleyici, aes(x=event_date))+
  geom_line(aes(y=log_sold))+
  labs(title="log(Sales) of La Roche over time")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
test_dates <- c(as.Date("2021-05-28"):as.Date("2021-06-11"))


for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- yuz_temizleyici[event_date<=current_date,]
  fitted_arima=arima(past_data$log_sold, xreg = past_data$price,order=c(2,1,4))
  forecasted=predict(fitted_arima,newxreg = yuz_temizleyici[event_date==test_dates[i],price],n.ahead = 2)
  yuz_temizleyici[nrow(yuz_temizleyici)-length(test_dates)+i, Model1 := forecasted$pred[2]]
} 

t<-accu(yuz_temizleyici$sold_count[(nrow(yuz_temizleyici)+1-length(test_dates)):(nrow(yuz_temizleyici))],exp(yuz_temizleyici$Model1[(nrow(yuz_temizleyici)+1-length(test_dates)):(nrow(yuz_temizleyici))]))




## ------------------------------------------------------------------------------------------------------------------------------------------------------------
for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- yuz_temizleyici[event_date<=current_date,]
  fitted_arima=arima(diff(past_data$log_sold,15),order=c(1,0,0),seasonal = c(2,0,3)) 
  forecasted=predict(fitted_arima,n.ahead = 2)
  yuz_temizleyici[nrow(yuz_temizleyici)-length(test_dates)+i,Model2:=(yuz_temizleyici[nrow(yuz_temizleyici)-length(test_dates)+i-15,log_sold]+forecasted$pred[2])]
}

t2<-accu(yuz_temizleyici$sold_count[(nrow(yuz_temizleyici)+1-length(test_dates)):(nrow(yuz_temizleyici))],exp(yuz_temizleyici$Model2[(nrow(yuz_temizleyici)+1-length(test_dates)):(nrow(yuz_temizleyici))]))




## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------


for(i in 1:length(test_dates)){
  
  current_date=test_dates[i]-2
  
  past_data <- yuz_temizleyici[event_date<=current_date,]
  
  yuz_temizleyici_ts <- ts(past_data$log_sold, frequency = 15)
  yuz_temizleyici_decomposed <- decompose(yuz_temizleyici_ts,type = "additive")
  model <- arima(yuz_temizleyici_decomposed$random,order = c(3,0,2))
  forecasted=predict(model,n.ahead = 2)
  yuz_temizleyici[nrow(yuz_temizleyici)-length(test_dates)+i,Model3:=forecasted$pred[2]+yuz_temizleyici_decomposed$seasonal[(nrow(yuz_temizleyici)-length(test_dates)+i)%%15+15]+yuz_temizleyici_decomposed$trend[max(which(!is.na(yuz_temizleyici_decomposed$trend)))]]
}

t3<-accu(yuz_temizleyici$sold_count[(nrow(yuz_temizleyici)+1-length(test_dates)):(nrow(yuz_temizleyici))],exp(yuz_temizleyici$Model3[(nrow(yuz_temizleyici)+1-length(test_dates)):(nrow(yuz_temizleyici))]))



## ------------------------------------------------------------------------------------------------------------------------------------------------------------


yuz_temizleyici[,pred1:=exp(Model1)]
yuz_temizleyici[,pred2:=exp(Model2)]
yuz_temizleyici[,pred3:=exp(Model3)]



## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
ggplot(dis_fircasi,aes(x=event_date))+
  geom_line(aes(y=exp(Model1)), color="red")+
  xlim(as.Date("2021-05-28"),as.Date("2021-06-11"))+ #Update here
  geom_line(aes(y=sold_count))+
  geom_line(aes(y=exp(Model2)),color="blue")+
  labs(title="Oral B - Actual vs. Predicted over time")

## ------------------------------------------------------------------------------------------------------------------------------------------------------------
rbind(c("Model 1", m),c("Model 2",m2))


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
ggplot(bebek_mendil,aes(x=event_date))+
  geom_line(aes(y=exp(Model1)), color="red")+
  xlim(as.Date("2021-05-28"),as.Date("2021-06-11"))+ #Update here
  geom_line(aes(y=sold_count))+
  geom_line(aes(y=exp(Model2)),color="blue")+
  geom_line(aes(y=exp(Model3)),color="green")+
  geom_line(aes(y=exp(Model4)),color="purple")+
  labs(title="Sleepy - Actual vs. Predicted over time")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
rbind(c("Model 1", s),c("Model 2",s2),c("Model 3", s3),c("Model 4",s4))


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
ggplot(yuz_temizleyici,aes(x=event_date))+
  geom_line(aes(y=exp(Model1)), color="red")+
  xlim(as.Date("2021-05-28"),as.Date("2021-06-11"))+ #Update here
  geom_line(aes(y=sold_count))+
  geom_line(aes(y=exp(Model2)),color="blue")+
  geom_line(aes(y=exp(Model3)),color="green")+
  labs(title="La Roche - Actual vs. Predicted over time")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
rbind(c("Model 1", t),c("Model 2",t2),c("Model 3", t3))


## ----pressure, echo=FALSE------------------------------------------------------------------------------------------------------------------------------------

get_token <- function(username, password, url_site){
  
  post_body = list(username=username,password=password)
  post_url_string = paste0(url_site,'/token/')
  result = POST(post_url_string, body = post_body)
  
  # error handling (wrong credentials)
  if(result$status_code==400){
    print('Check your credentials')
    return(0)
  }
  else if (result$status_code==201){
    output = content(result)
    token = output$key
  }
  
  return(token)
}

get_data <- function(start_date='2020-03-20', token, url_site){
  
  post_body = list(start_date=start_date,username=username,password=password)
  post_url_string = paste0(url_site,'/dataset/')
  
  header = add_headers(c(Authorization=paste('Token',token,sep=' ')))
  result = GET(post_url_string, header, body = post_body)
  output = content(result)
  data = data.table::rbindlist(output)
  data[,event_date:=as.Date(event_date)]
  data = data[order(product_content_id,event_date)]
  return(data)
}


send_submission <- function(predictions, token, url_site, submit_now=F){
  
  format_check=check_format(predictions)
  if(!format_check){
    return(FALSE)
  }
  
  post_string="list("
  for(i in 1:nrow(predictions)){
    post_string=sprintf("%s'%s'=%s",post_string,predictions$product_content_id[i],predictions$forecast[i])
    if(i<nrow(predictions)){
      post_string=sprintf("%s,",post_string)
    } else {
      post_string=sprintf("%s)",post_string)
    }
  }
  
  submission = eval(parse(text=post_string))
  json_body = jsonlite::toJSON(submission, auto_unbox = TRUE)
  submission=list(submission=json_body)
  
  print(submission)
  # {"31515569":2.4,"32737302":2.4,"32939029":2.4,"4066298":2.4,"48740784":2.4,"6676673":2.4, "7061886":2.4, "73318567":2.4, "85004":2.4} 
  
  if(!submit_now){
    print("You did not submit.")
    return(FALSE)      
  }
  
  
  header = add_headers(c(Authorization=paste('Token',token,sep=' ')))
  post_url_string = paste0(url_site,'/submission/')
  result = POST(post_url_string, header, body=submission)
  
  if (result$status_code==201){
    print("Successfully submitted. Below you can see the details of your submission")
  } else {
    print("Could not submit. Please check the error message below, contact the assistant if needed.")
  }
  
  print(content(result))
  
}

check_format <- function(predictions){
  
  if(is.data.frame(predictions) | is.data.frame(predictions)){
    if(all(c('product_content_id','forecast') %in% names(predictions))){
      if(is.numeric(predictions$forecast)){
        print("Format OK")
        return(TRUE)
      } else {
        print("forecast information is not numeric")
        return(FALSE)                
      }
    } else {
      print("Wrong column names. Please provide 'product_content_id' and 'forecast' columns")
      return(FALSE)
    }
    
  } else {
    print("Wrong format. Please provide data.frame or data.table object")
    return(FALSE)
  }
  
}

# this part is main code
subm_url = 'http://46.101.163.177'

u_name = "Group8"
p_word = "aBbYZj795YeGEupS"
submit_now = FALSE

username = u_name
password = p_word

token = '84ea343ee6df0a64d2b63baaac94745d6f668072'
#token = get_token(username=u_name, password=p_word, url=subm_url)

data = get_data(token=token,url=subm_url)
combine_data <- data[event_date > as.Date('2021-05-31')]

#predictions=unique(data[,list(product_content_id)])
#predictions[,forecast:=2.3]

#send_submission(predictions, token, url=subm_url, submit_now=F)

ProjectRawData <- read_csv("ProjectRawData.csv")

raw_data <- rbind(ProjectRawData ,combine_data)




## ------------------------------------------------------------------------------------------------------------------------------------------------------------
raw_data <- data.table(raw_data)
raw_data[, "event_date" := as.Date(event_date)]
raw_data <- raw_data[event_date >= '2020-05-25']
raw_data[, month := month(event_date, label = TRUE)]
raw_data[, wday := wday(event_date, label = TRUE)]
raw_data <- raw_data[order(event_date),]


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
data_leopar <- raw_data[product_content_id == 73318567] #leopar


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(data_leopar, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red") + ggtitle("Sales of Leopard Bikini") + xlab("day") + ylab("Sales")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(data_leopar$sold_count)
pacf(data_leopar$sold_count)


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
leopar <- data_leopar
numeric_data <- leopar
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)




## ------------------------------------------------------------------------------------------------------------------------------------------------------------
leopar <- leopar[,favored_count_lag := shift(favored_count, 2)]
leopar <- leopar[,basket_count_lag := shift(basket_count, 2)]
leopar <- leopar[,visit_count_lag := shift(visit_count, 2)]

leopar_reduced <- leopar[event_date >= '2021-04-29'] 

numeric_data <- leopar_reduced
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(leopar_reduced, aes(x=event_date)) + 
  geom_line(aes(y = sold_count, color = "Sales")) + 
  geom_line(aes(y = price, color="Price")) + scale_x_date(date_breaks = "1 day", date_labels = "%d") + ggtitle("Sales of Leopard Bikini") + xlab("day") + ylab("Sales")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
leopar_reduced <- leopar_reduced[,stock_out := ifelse(sold_count < 75, 1, 0)]

leopar_reduced$stock_out <- as.factor(leopar_reduced$stock_out)

model1=lm(sold_count~ stock_out, leopar_reduced)

summary(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

model1=lm(sold_count~ stock_out + basket_count_lag, leopar_reduced)

summary(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

model1=lm(sold_count~ stock_out + basket_count_lag + visit_count_lag, leopar_reduced)

summary(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

model1=lm(sold_count ~ stock_out + basket_count_lag + visit_count_lag + favored_count_lag, leopar_reduced)
summary(model1)



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
leopar_reduced$wday <- as.factor(leopar_reduced$wday)
model=lm(sold_count ~ stock_out + basket_count_lag + visit_count_lag + favored_count_lag + wday, leopar_reduced)

summary(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(model1$residuals)
checkresiduals(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
modellastts <- (model1$residuals)
acf(modellastts)
pacf(modellastts)



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
auto.arima(modellastts)
modelarima1 <- arima(modellastts, order=c(1,0,0))
print(modelarima1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
modelarima <- arima(modellastts, order=c(4,0,0))
print(modelarima)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
modelarima <- arima(modellastts, order=c(4,0,1))
print(modelarima)



## ------------------------------------------------------------------------------------------------------------------------------------------------------------

predicted1 = modellastts - modelarima1$residuals 

leopar_reduced = leopar_reduced[, predictedlinear := leopar_reduced$sold_count - predicted1]

ggplot(leopar_reduced, aes(x=event_date)) + 
  geom_line(aes(y = sold_count, color = "Sales")) + 
  geom_line(aes(y = predictedlinear, color="Prediction")) + scale_x_date(date_breaks = "1 day", date_labels = "%d")+ ggtitle("Sales of Leopard Bikini") + xlab("day") + ylab("Sales")



## ------------------------------------------------------------------------------------------------------------------------------------------------------------

test_start=as.Date('2021-06-11')
test_end=as.Date('2021-06-30')

test_dates=seq(test_start,test_end,by='day')
leopar_reduced$Model1 =NULL
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- leopar_reduced[event_date<=current_date,]
  fitted_lm= lm(sold_count ~ stock_out, past_data)
  rm <- arima(fitted_lm$residual, order = c(0,0,1))
  forecasted=predict(fitted_lm,leopar_reduced[event_date == test_dates[i],])
  leopar_reduced[nrow(leopar_reduced)-length(test_dates)+i, Model1 := (forecasted+forecast(rm,h=2)$mean[2])]
  
}

  m_with_regression<-accu(leopar_reduced$sold_count[(nrow(leopar_reduced)-length(test_dates)-1):(nrow(leopar_reduced)-2)],(leopar_reduced$Model1[(nrow(leopar_reduced)+1-length(test_dates)):(nrow(leopar_reduced)-0)])) 



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(leopar_reduced$sold_count, main= "Daily Autocorrelation")
pacf(leopar_reduced$sold_count, main= "Daily Autocorrelation")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
leoparts <- ts(leopar_reduced$sold_count,freq=7)
data_mult<-decompose(leoparts,type="multiplicative")
random=data_mult$random
plot(data_mult)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_mult$seasonal[1:7], xlab = "Hour", ylab = "Multiplicative of Day", main = "Seasonal Component of Trend for Multiplicative")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=data_leopar[,list(m_sold = mean(sold_count,na.rm=T)), by="wday"]
mean_sold


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_mult$random) 
summary(unt_test)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
leoparts <- ts(leopar_reduced$sold_count,freq=7)
data_add<-decompose(leoparts,type="additive")
random1=data_add$random
plot(data_add)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_add$seasonal[1:7], xlab = "Hour", ylab = "Additive of Day", main = "Seasonal Component of Trend for Additive")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=data_leopar[,list(m_sold = mean(sold_count,na.rm=T)), by="wday"]
mean_sold


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_add$random) 
summary(unt_test)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(random, na.action = na.pass, main= "Detrend's Autocorrelation")
pacf(random, na.action = na.pass, main= "Detrend's Autocorrelation")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(3,0,0))
print(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
modelf <- arima(random, order=c(0,0,3))
print(modelf)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(3,0,3))
print(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
leopar_reduced = leopar_reduced[,random := data_mult$random]
reg_matrix=cbind( leopar_reduced$stock_out) # can add more if any other regressors exist
   model1 <- arima(leopar_reduced$random, order = c(0,0,3), xreg = reg_matrix)
  summary(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

reg_matrix=cbind( leopar_reduced$stock_out, leopar_reduced$basket_count_lag, leopar_reduced$visit_count_lag) # can add more if any other regressors exist
   modelwithreg <- arima(leopar_reduced$random, order = c(0,0,3), xreg = reg_matrix)
  summary(modelwithreg)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

model_fitted <- leopar_reduced$random - residuals(modelwithreg)
leopar_reduced <- cbind(leopar_reduced, data_mult$seasonal, data_mult$trend, model_fitted)
leopar_reduced <-leopar_reduced[,predictwithreg := data_mult$seasonal * data_mult$trend * model_fitted] 

model_fitted_2 <- leopar_reduced$random - residuals(modelf)
leopar_reduced <- cbind(leopar_reduced, model_fitted_2)
leopar_reduced <-leopar_reduced[,predictonlyarima := data_mult$seasonal * data_mult$trend * model_fitted_2] 


ggplot(leopar_reduced, aes(x=event_date)) + 
  geom_line(aes(y = sold_count, color = "Actual Sales" )) +
  geom_line(aes(y =predictwithreg, color = "ARIMAX Prediction" ))  +
   geom_line(aes(y = predictonlyarima, color = "ARIMA Predcition")) +
    geom_line(aes(y = predictedlinear, color = "Linear Predcition")) + ggtitle("Sales of Leopard Bikini") + xlab("day") + ylab("Sales")


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------

train_start=as.Date('2021-01-23')
test_start=as.Date('2021-06-11')
test_end=as.Date('2021-06-30')

test_dates=seq(test_start,test_end,by='day')

for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- leopar_reduced[event_date<=current_date,]
    
    leopar_ts <- ts(past_data$sold_count, frequency = 7)  
    leopar_decomposed <- decompose(leopar_ts, type="multiplicative")
    
    reg_matrix=cbind( past_data$stock_out, past_data$basket_count_lag, past_data$visit_count_lag) 
    
    model <- arima(leopar_decomposed$random,order = c(0,0,3),xreg = reg_matrix)
    
    forecasted=predict(model,n.ahead = 2,newxreg = leopar_reduced[event_date==test_dates[i],cbind(stock_out,basket_count_lag,visit_count_lag)])
    leopar_reduced[nrow(leopar_reduced)-length(test_dates)+i-2, Model_reg := forecasted$pred[2]*leopar_decomposed$seasonal[(nrow(leopar_reduced)-length(test_dates)+i-2)%%7+7]*leopar_decomposed$trend[max(which(!is.na(leopar_decomposed$trend)))]]
  }
  m_with_reg<-accu(leopar_reduced$sold_count[(nrow(leopar_reduced)-1-length(test_dates)):(nrow(leopar_reduced)-2)],(leopar_reduced$Model_reg[(nrow(leopar_reduced)-1-length(test_dates)):(nrow(leopar_reduced)-2)]))  
 


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- leopar_reduced[event_date<=current_date,]
    
    leopar_ts <- ts(past_data$sold_count, frequency = 7)  
    leopar_decomposed <- decompose(leopar_ts, type="multiplicative")
    model <- arima(leopar_decomposed$random,order = c(0,0,3))
    
    forecasted=predict(model,n.ahead = 2)
    leopar_reduced[nrow(leopar_reduced)-length(test_dates)+i-2, Model_nolag := forecasted$pred[2]*leopar_decomposed$seasonal[(nrow(leopar_reduced)-length(test_dates)+i-2)%%7+7]*leopar_decomposed$trend[max(which(!is.na(leopar_decomposed$trend)))]]
  }
  m_only_arima<-accu(leopar_reduced$sold_count[(nrow(leopar_reduced)-1-length(test_dates)):(nrow(leopar_reduced)-2)],(leopar_reduced$Model_nolag[(nrow(leopar_reduced)-1-length(test_dates)):(nrow(leopar_reduced)-2)]))  


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
rbind(m_with_reg,m_only_arima, m_with_regression)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
data_siyah <- raw_data[product_content_id == 32737302] 


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(data_siyah, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red") + ggtitle("Sales of Black Bikini") + xlab("day") + ylab("Sales")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(data_siyah$sold_count, main= "Daily Autocorrelation")
siyah <- data_siyah


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
siyah <- siyah[event_date >= '2021-02-20'] 


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(siyah, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red") + ggtitle("Sales of Black Bikini") + xlab("day") + ylab("Sales")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(log(siyah$sold_count), main= "Daily Autocorrelation")
pacf(log(siyah$sold_count), main= "Daily Autocorrelation")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
siyahts <- ts(log(siyah$sold_count),freq=7)
data_mult<-decompose(siyahts,type="multiplicative")
random=data_mult$random
plot(data_mult)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_mult$seasonal[1:7], xlab = "Hour", ylab = "Multiplicative of Day", main = "Seasonal Component of Trend for Multiplicative")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=siyah[,list(mean_sold = mean(log(sold_count),na.rm=T)), by="wday"]
mean_sold


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_mult$random) 
summary(unt_test)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
siyahts <- ts(log(siyah$sold_count),freq=7)
data_add<-decompose(siyahts,type="additive")
random=data_add$random
plot(data_add)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_add$seasonal[1:7], xlab = "Hour", ylab = "Additive of Day", main = "Seasonal Component of Trend for Additive")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_add$random) 
summary(unt_test)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(random, na.action = na.pass, main= "Detrend's Autocorrelation")
pacf(random, na.action = na.pass, main= "Detrend's Autocorrelation")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(6,0,0))
print(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
modelf <- arima(random, order=c(0,0,3))
print(modelf)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(6,0,3))
print(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
modelf <- arima(random, order=c(6,0,4))
print(modelf)


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
siyah <- siyah[, random := data_add$random]
numeric_data <- siyah
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)




## ------------------------------------------------------------------------------------------------------------------------------------------------------------
siyah <- siyah[,category_sold_lag := shift(category_sold, 2)]
siyah <- siyah[,basket_count_lag := shift(basket_count, 2)]
siyah <- siyah[,visit_count_lag := shift(visit_count, 2)]

numeric_data <- siyah
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind( siyah$basket_count_lag)
   model1 <- arima(siyah$random,order = c(6,0,4), xreg = reg_matrix)
  summary(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind( siyah$visit_count_lag, siyah$basket_count_lag) 

   model2 <- arima(siyah$random,order = c(6,0,4), xreg = reg_matrix)
  summary(model2)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

model_fitted <- siyah$random - residuals(model1)
siyah <- cbind(siyah, data_add$seasonal, data_add$trend, model_fitted)
siyah <-siyah[,predictarima := exp(data_add$seasonal + data_add$trend + model_fitted) ] 

model_fitted_2 <- siyah$random - residuals(modelf)
siyah <- cbind(siyah, model_fitted_2)
siyah <-siyah[,predictonlyar := exp(data_add$seasonal + data_add$trend + model_fitted_2)] 

ggplot(siyah, aes(x=event_date)) + 
  geom_line(aes(y = sold_count, color = "Actual Sales")) + 
  geom_line(aes(y = predictarima, color="ARIMA Prediction")) +
  geom_line(aes(y = predictonlyar, color="ARIMAX Prediction")) + ggtitle("Sales of Black Bikini") + xlab("day") + ylab("Sales")



## ------------------------------------------------------------------------------------------------------------------------------------------------------------

train_start=as.Date('2021-01-23')
test_start=as.Date('2021-06-24')
test_end=as.Date('2021-06-30')

test_dates=seq(test_start,test_end,by='day')

for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- siyah[event_date<=current_date,]
    
    siyah_ts <- ts(log(past_data$sold_count), frequency = 7)  
    siyah_decomposed <- decompose(siyah_ts, type="additive")
    model <- arima(siyah_decomposed$random,order = c(6,0,4),xreg = past_data$basket_count_lag)
    
    forecasted=predict(model,n.ahead = 2,newxreg = siyah[event_date==test_dates[i],basket_count_lag])
    siyah[nrow(siyah)-length(test_dates)+i-2, Model_reg :=  forecasted$pred[2]+siyah_decomposed$seasonal[(nrow(siyah)-length(test_dates)+i-2)%%7+7]+siyah_decomposed$trend[max(which(!is.na(siyah_decomposed$trend)))]]
}
siyah$Model_reg <- exp(siyah$Model_reg)
  m_with_lag<-accu(siyah$sold_count[(nrow(siyah)-1-length(test_dates)):(nrow(siyah)-2)],(siyah$Model_reg[(nrow(siyah)-1-length(test_dates)):(nrow(siyah)-2)]))  
 


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------

for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- siyah[event_date<=current_date,]
    
    siyah_ts <- ts(log(past_data$sold_count), frequency = 7)  
    siyah_decomposed <- decompose(siyah_ts, type="additive")
    model <- arima(siyah_decomposed$random,order = c(6,0,4))
    
    forecasted=predict(model,n.ahead = 2)
    siyah[nrow(siyah)-length(test_dates)+i-2, Model_no_reg := forecasted$pred[2]+siyah_decomposed$seasonal[(nrow(siyah)-length(test_dates)+i-2)%%7+7]+siyah_decomposed$trend[max(which(!is.na(siyah_decomposed$trend)))]]
}
siyah$Model_no_reg <- exp(siyah$Model_no_reg)
  m_without_lag<-accu(siyah$sold_count[(nrow(siyah)-1-length(test_dates)):(nrow(siyah)-2)],(siyah$Model_no_reg[(nrow(siyah)-1-length(test_dates)):(nrow(siyah)-2)]))  
  

## ------------------------------------------------------------------------------------------------------------------------------------------------------------
rbind( m_with_lag, m_without_lag )


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
data_tayt <- raw_data[product_content_id == 31515569]


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(data_tayt, aes(x=event_date)) + 
  geom_line(aes(y = sold_count), color = "red") + ggtitle("Sales of Leggings") + xlab("day") + ylab("Sales")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(data_tayt$sold_count, main= "Daily Autocorrelation")
pacf(data_tayt$sold_count, main= "Daily Autocorrelation")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
tayt <- data_tayt
taytts <- ts(tayt$sold_count,freq=7)
data_mult<-decompose(taytts,type="multiplicative")
random=data_mult$random
plot(data_mult)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_mult$seasonal[1:7], xlab = "Hour", ylab = "Multiplicative of Day", main = "Seasonal Component of Trend for Multiplicative")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
mean_sold=tayt[,list(mean_sold = mean(sold_count,na.rm=T)), by="wday"]
mean_sold


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_mult$random) 
summary(unt_test)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
taytts <- ts(tayt$sold_count,freq=7)
data_add<-decompose(taytts,type="additive")
random=data_add$random
plot(data_add)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_add$seasonal[1:7], xlab = "Hour", ylab = "Additive of Day", main = "Seasonal Component of Trend for Additive")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_add$random) 
summary(unt_test)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
taytts <- ts(tayt$sold_count,freq=16)
data_add_2<-decompose(taytts,type="additive")
plot(data_add_2)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(data_add_2$seasonal[1:16], xlab = "Hour", ylab = "Additive of Day", main = "Seasonal Component of Trend for Additive")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
unt_test=ur.kpss(data_add_2$random) 
summary(unt_test)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
acf(random, na.action = na.pass, main= "Detrend's Autocorrelation")
pacf(random, na.action = na.pass, main= "Detrend's Autocorrelation")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(4,0,0))
print(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(0,0,4))
print(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(4,0,4))
print(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- arima(random, order=c(3,0,4))
print(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
modelf <- arima(random, order=c(4,0,3))
print(modelf)


## ---- warning=FALSE------------------------------------------------------------------------------------------------------------------------------------------
tayt <- tayt[, random := data_add$random]
numeric_data <- tayt
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)




## ------------------------------------------------------------------------------------------------------------------------------------------------------------
tayt <- tayt[,category_sold_lag := shift(category_sold, 2)]
tayt <- tayt[,basket_count_lag := shift(basket_count, 2)]
tayt <- tayt[,favored_count_lag := shift(favored_count, 2)]
tayt <- tayt[,price_lag := shift(price, 2)]

numeric_data <- tayt
numeric_data$event_date = NULL
numeric_data$product_content_id = NULL
numeric_data$trend= NULL
numeric_data$month= NULL
numeric_data$wday= NULL
numeric_data$random= as.numeric(numeric_data$random)
numeric_data <- na.omit(numeric_data)
str(numeric_data)

correl_info = cor(numeric_data)
ggcorrplot(correl_info, hc.order = TRUE, type = "lower",lab = TRUE)



## ------------------------------------------------------------------------------------------------------------------------------------------------------------

reg_matrix=cbind( tayt$basket_count_lag) # can add more if any other regressors exist
   model1 <- arima(tayt$random,order = c(4,0,3), xreg = reg_matrix)
  summary(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind(tayt$category_sold_lag) 

   model1 <- arima(tayt$random,order = c(4,0,3), xreg = reg_matrix)
  summary(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
reg_matrix=cbind(tayt$category_sold_lag) 

   model1 <- arima(tayt$random,order = c(4,0,3), xreg = reg_matrix)
  summary(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

model_fitted <- tayt$random - residuals(model1)
tayt <- cbind(tayt, data_add$seasonal, data_add$trend, model_fitted)
tayt <-tayt[,predictarima := data_add$seasonal + data_add$trend + model_fitted  ] 

model_fitted_2 <- tayt$random - residuals(modelf)
tayt <- cbind(tayt,model_fitted_2)
tayt <-tayt[,predictarima_no_reg := data_add$seasonal + data_add$trend + model_fitted_2  ] 

ggplot(tayt, aes(x=event_date)) + 
  geom_line(aes(y = sold_count, color = "sold_count")) + 
  geom_line(aes(y = predictarima, color = "only_arima_prediction")) + 
   geom_line(aes(y = predictarima_no_reg, color = "arima_with_lag")) + ggtitle("Sales of Leggings") + xlab("day") + ylab("Sales")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------

train_start=as.Date('2021-01-23')
test_start=as.Date('2021-06-23')
test_end=as.Date('2021-06-30')

test_dates=seq(test_start,test_end,by='day')

for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- tayt[event_date<=current_date,]
    
    tayt_ts <- ts(past_data$sold_count, frequency = 7)  
    tayt_decomposed <- decompose(tayt_ts, type="additive")
    model <- arima(tayt_decomposed$random,order = c(4,0,3),xreg = past_data$basket_count_lag)
    
    forecasted=predict(model,n.ahead = 2,newxreg = tayt[event_date==test_dates[i],basket_count_lag])
    tayt[nrow(tayt)-length(test_dates)+i-2, Model_reg := forecasted$pred[2]+tayt_decomposed$seasonal[(nrow(tayt)-length(test_dates)+i-2)%%7+7]+tayt_decomposed$trend[max(which(!is.na(tayt_decomposed$trend)))]]
  }
  m_with_7<-accu(tayt$sold_count[(nrow(tayt)-1-length(test_dates)):(nrow(tayt)-2)],(tayt$Model_reg[(nrow(tayt)-1-length(test_dates)):(nrow(tayt)-2)]))  
 


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
for(i in 1:length(test_dates)){
    
    current_date=test_dates[i]-2
    
    past_data <- tayt[event_date<=current_date,]
    
    tayt_ts <- ts(past_data$sold_count, frequency =7)  
    tayt_decomposed <- decompose(tayt_ts, type="additive")
    model <- arima(tayt_decomposed$random,order = c(4,0,3))
    
    forecasted=predict(model,n.ahead = 2)
    tayt[nrow(tayt)-length(test_dates)+i-2, Model_noreg := forecasted$pred[2]+tayt_decomposed$seasonal[(nrow(tayt)-length(test_dates)+i-2)%%7+7]+tayt_decomposed$trend[max(which(!is.na(tayt_decomposed$trend)))]]
  }
  m_with_no_reg<-accu(tayt$sold_count[(nrow(tayt)-1-length(test_dates)):(nrow(tayt)-2)],(tayt$Model_noreg[(nrow(tayt)-1-length(test_dates)):(nrow(tayt)-2)]))  
 


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
rbind(m_with_7,m_with_no_reg)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
tayt_reduced <- na.omit(data_tayt)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model = lm(sold_count~ basket_count_lag + price, tayt_reduced)
summary(model)

## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model = lm(sold_count~ basket_count_lag + favored_count_lag + price, tayt_reduced)
summary(model)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model1 = lm(sold_count~ basket_count_lag + category_sold_lag + price, tayt_reduced)
summary(model1)


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
plot(model1$residuals)

checkresiduals(model1$residuals) 



## ------------------------------------------------------------------------------------------------------------------------------------------------------------
modellastts <- ts(model1$residuals)

modelarima1 <- arima(modellastts, order=c(4,0,1))
print(modelarima1)
AIC(modelarima1)
BIC(modelarima1)

auto.arima(modellastts)

predicted1 = modellastts - modelarima1$residuals 

tayt_reduced = tayt_reduced[, predictedlinear := tayt_reduced$sold_count - predicted1]

ggplot(tayt_reduced, aes(x=event_date)) + 
  geom_line(aes(y = sold_count, color = "Actual Sales")) + 
  geom_line(aes(y = predictedlinear, color="Prediction")) + scale_x_date(date_breaks = "1 day", date_labels = "%d") + ggtitle("Sales of Leggings") + xlab("day") + ylab("Sales")


## ------------------------------------------------------------------------------------------------------------------------------------------------------------
model_forecast <- tail(predict(modelarima1, n.ahead = 2)$pred,1)

x <- cbind(tail(tayt_reduced$basket_count,1),tail(tayt_reduced$category_sold,1),56)
x <- as.data.table(x)
names(x) = c("basket_count_lag",  "category_sold_lag", "price")

p <- predict(model1, x) + tail(predict(modelarima1, n.ahead = 2)$pred,1)
print(p)

