source("Functions.r")

# Xiaomi ----
xiaomi <- ArrangeTrainData(6676673)

head(xiaomi)
tail(xiaomi)

xiaomi <- xiaomi[order(event_date),]
skim(xiaomi)
lapply(xiaomi, function(x){ length(which(x==0))/length(x)})

# Cross-correlations with lag 2. Data from two days before will available when we make our predictions. Only price data
# will be available with lag 1.
auto <- c()
for(i in 3:13){
  x <- ccf(xiaomi[,4], xiaomi[,..i], plot = FALSE)
  auto[i-2] <- x[2]$acf
}
auto

# Plots of the time series data.
ggplot(xiaomi, aes(x = event_date)) +
  geom_line(aes(y = price))
ggplot(xiaomi, aes(x = event_date)) +
  geom_line(aes(y = basket_count))
ggplot(xiaomi, aes(x = event_date)) +
  geom_line(aes(y = category_sold))
ggplot(xiaomi, aes(x = event_date)) +
  geom_line(aes(y = category_visits))
ggplot(xiaomi, aes(x = event_date)) +
  geom_line(aes(y = category_favored))

# Creating lagged variables
xiaomi[,price_lag1 := shift(price,1)]
xiaomi[,basket_count_lag2 := shift(basket_count,2)]
xiaomi[,category_favored_lag2 := shift(category_favored,2)]
xiaomi[,category_sold_lag2 := shift(category_sold,2)]
xiaomi[,category_visits_lag2 := shift(category_visits,2)]

xiaomi[,mean(sold_count), by = .(wday)]

# Descriptive Analysis
ggplot(xiaomi) +
  geom_boxplot(aes(y = sold_count))
ggplot(xiaomi) +
  geom_histogram(aes(x = sold_count))
ggplot(xiaomi, aes(x = event_date)) +
  geom_line(aes(y = sold_count)) # variance constant, data not stationatry (trend + season effects)

# Removing Outliers
quant <- quantile(xiaomi$sold_count,probs=c(0.25,0.75), na.rm = TRUE)
iqr <- IQR(xiaomi$sold_count)
up <-  quant[2]+1.5*iqr
low <- quant[1]-1.5*iqr 
xiaomi_with_outliers <- xiaomi
xiaomi_with_outliers[sold_count<=low | sold_count>=up,]
xiaomi <- xiaomi[sold_count>=low & sold_count<=up,]

# ggplot(raw_data[product_content_id == 6676673,], aes(x = event_date)) +
#   geom_line(aes(y = category_sold))
# raw_data[product_content_id == 6676673]

# Checking Autocorrelations
acf(xiaomi$sold_count, lag.max = 40) #Autoregressive signature sinusodial/ expo decreasing --> maybe seasonality
pacf(xiaomi$sold_count, lag.max = 40)
ccf(xiaomi$sold_count,xiaomi$basket_count)
ccf(xiaomi$sold_count,xiaomi$category_favored)

# Dynamic Regression -> Trend Season Other + ARIMA on Errors ----
correl <- cor(xiaomi[,c(4,17:21)])
ggcorrplot(correl, hc.order = TRUE, type = 'lower')
ggpairs(xiaomi[,c(4,17:21)]) # visit count lag, price, basket lag, cat sold lag, favored_count lag, cat favored lag

m11 <- lm(sold_count~trend+month, xiaomi)
summary(m11)
AIC(m11)
checkresiduals(m11) # residuals not good

m12 <- lm(sold_count ~ trend + month + wday, xiaomi)
summary(m12)
AIC(m12) #AIC did not improve, r2 improved, regression with trend and wday also not good

m13 <- lm(sold_count ~ trend + month + price_lag1, xiaomi)
summary(m13)
AIC(m13)
checkresiduals(m13)

m13b <- lm(sold_count ~ trend + month + wday + price_lag1, xiaomi)
summary(m13b)
AIC(m13b)
checkresiduals(m13b)

# m14 <- lm(sold_count ~ trend + month + price + basket_count + category_favored, xiaomi)
# summary(m14)
# AIC(m14)
# checkresiduals(m14)

m14b <- lm(sold_count ~ trend + month + price_lag1  + wday + basket_count_lag2 + category_sold_lag2, xiaomi)
summary(m14b)
AIC(m14b)
checkresiduals(m14b)

m14c <- lm(sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_visits_lag2 + category_favored_lag2, xiaomi)
summary(m14c)
AIC(m14c)
checkresiduals(m14c)

m14d <- lm(sold_count ~ trend + month + price_lag1 + basket_count_lag2 + category_sold_lag2 + category_visits_lag2 + category_favored_lag2, xiaomi)
summary(m14d)
AIC(m14d)
checkresiduals(m14c)

# Find the best arima m14c----
random1 <- ts(m14c$residuals, frequency = 30)
summary(ur.kpss(random1, use.lag = 30))

#random is stationary, begin arima check pacf and acf
acf(m14c$residuals, lag.max = 40)
pacf(m14c$residuals, lag.max = 40)
tsdisplay(random1)

d11 <- arima(random1, order = c(0,0,0))
d12 <- arima(random1, order = c(2,0,2)) 
d13 <- arima(random1, order = c(1,0,0)) # 
d14 <- arima(random1, order = c(0,0,1))
AIC(d11)
AIC(d12)
AIC(d13)
AIC(d14)

d15 <- arima(random1, order = c(2,0,0))
d16 <- arima(random1, order = c(1,0,1))
d17 <- arima(random1, order = c(1,0,0), include.mean = FALSE)
AIC(d15)
AIC(d16)
AIC(d17)
AIC(d13)

d18 <- arima(random1, order = c(1,0,1), include.mean = FALSE) #best
d19 <- arima(random1, order = c(0,0,0), include.mean = FALSE) 
d110 <- arima(random1, order = c(2,0,0), include.mean = FALSE)
AIC(d18)
AIC(d19)
AIC(d110)

d111 <- arima(random1, order = c(1,0,2), include.mean = FALSE)
d112 <- arima(random1, order = c(0,0,1), include.mean = FALSE)
d113 <- arima(random1, order = c(2,0,1), include.mean = FALSE)
AIC(d111)
AIC(d112)
AIC(d113)

autoarima1 <- auto.arima(random1, trace = TRUE)

checkresiduals(d18)
alt1_fitted <- fitted(d18) + m14c$fitted.values
tsdisplay(ts(xiaomi$sold_count-xiaomi$Model2Fitted))
xiaomi[,Model1Fitted := c(NA,NA,alt1_fitted)]
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model1Fitted, color = "fitted"))
  
# Find the best arima m14b ----
random2 <- ts(m14b$residuals, frequency = 30)
summary(ur.kpss(random2, use.lag = 30))

#random is stationary, begin arima check pacf and acf
acf(m14b$residuals, lag.max = 40)
pacf(m14b$residuals, lag.max = 40)
tsdisplay(random2)

e11 <- arima(random2, order = c(0,0,0))
e12 <- arima(random2, order = c(2,0,2)) #best
e13 <- arima(random2, order = c(1,0,0))
e14 <- arima(random2, order = c(0,0,1))
AIC(e11)
AIC(e12)
AIC(e13)
AIC(e14)

e15 <- arima(random2, order = c(1,0,2))
e16 <- arima(random2, order = c(3,0,2)) 
e17 <- arima(random2, order = c(2,0,3))
e18 <- arima(random2, order = c(2,0,1)) #best
e19 <- arima(random2, order = c(2,0,2), include.mean = FALSE)
AIC(e15)
AIC(e16)
AIC(e17)
AIC(e18)
AIC(e19)

e110 <- arima(random2, order = c(4,0,2))
e111 <- arima(random2, order = c(3,0,1)) 
e112 <- arima(random2, order = c(3,0,3))
e113 <- arima(random2, order = c(3,0,2), include.mean = FALSE) #best
AIC(e110)
AIC(e111)
AIC(e112)
AIC(e113)

e114 <- arima(random2, order = c(3,0,1), include.mean = FALSE)
e115 <- arima(random2, order = c(3,0,3), include.mean = FALSE) #best
e116 <- arima(random2, order = c(2,0,2), include.mean = FALSE)
e117 <- arima(random2, order = c(4,0,2), include.mean = FALSE) 
AIC(e114)
AIC(e115)
AIC(e116)
AIC(e117)

e118 <- arima(random2, order = c(3,0,4), include.mean = FALSE)
e119 <- arima(random2, order = c(2,0,3), include.mean = FALSE) 
e120 <- arima(random2, order = c(4,0,3), include.mean = FALSE)
e121 <- arima(random2, order = c(3,0,3)) 
AIC(e118)
AIC(e119)
AIC(e120)
AIC(e121)

autoarima2 <- auto.arima(random2)

checkresiduals(e115)
alt2_fitted <- fitted(e115) + m14b$fitted.values
tsdisplay(ts(xiaomi$sold_count-xiaomi$Model2Fitted))
xiaomi[,Model2Fitted := c(NA,NA,alt2_fitted)]
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model2Fitted, color = "fitted"))

# Sarimax ----
xiaomi_ts <- ts(xiaomi$sold_count)

xiaomi_sarima <- auto.arima(xiaomi_ts, trace = TRUE, seasonal = TRUE)
summary(xiaomi_sarima)
AIC(xiaomi_sarima)

checkresiduals(xiaomi_sarima)
tsdisplay(xiaomi_sarima$residuals)
xiaomi[,Model3Fitted := xiaomi_sarima$fitted]
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model3Fitted, color = "fitted"))

y <- data.frame(xiaomi_sarima$x, xiaomi_sarima$fitted)
ggplot(y, aes(x=xiaomi_sarima.x )) +
  geom_point(aes( y = xiaomi_sarima.fitted)) +
  geom_abline(slope = 1, intercept = 0)

xiaomi_sarimax <- auto.arima(xiaomi_ts[3:360],
                             xreg =matrix(c(xiaomi$price_lag1[3:nrow(xiaomi)],
                                            xiaomi$basket_count_lag2[3:nrow(xiaomi)],
                                            xiaomi$category_sold_lag2[3:nrow(xiaomi)]), nrow = nrow(xiaomi)-2),
                             trace = TRUE, seasonal = TRUE)
AIC(xiaomi_sarimax)
y <- data.frame(xiaomi_sarimax$x, xiaomi_sarimax$fitted)
ggplot(y, aes(x=xiaomi_sarimax.x )) +
  geom_point(aes( y = xiaomi_sarimax.fitted)) +
  geom_abline(slope = 1, intercept = 0)

summary(ur.kpss(xiaomi_ts, use.lag = 32))

#Model without regressors: ARIMA ar(3) + mean 4799.68 /.518 (sarima)
#Model with regressors: ARIMA ar(2) + + d(1) + ma(1) with mean 4619.74 but again without regressors (sarimax)

predict(xiaomi_sarimax, n.ahead = 1)

# Decomposition ----
acf(xiaomi$sold_count, lag.max = 40)

xiaomi_ts <- ts(xiaomi$sold_count, frequency = 28)

xiaomi_ts_dec <- decompose(xiaomi_ts)
summary(ur.kpss(xiaomi_ts_dec$random))

xiaomi_dec_tre <- xiaomi_ts_dec$trend
xiaomi_dec_ran <- xiaomi_ts_dec$random
xiaomi_dec_sea <- xiaomi_ts_dec$seasonal

holt(xiaomi_dec_tre[15:346],15)
r_auto <- auto.arima(xiaomi_dec_ran, trace = TRUE)

r11 <- arima(xiaomi_dec_ran, order = c(0,0,0))
r12 <- arima(xiaomi_dec_ran, order = c(2,0,2)) 
r13 <- arima(xiaomi_dec_ran, order = c(1,0,0))  
r14 <- arima(xiaomi_dec_ran, order = c(0,0,1))
AIC(r11)
AIC(r12)
AIC(r13)
AIC(r14)

r15 <- arima(xiaomi_dec_ran, order = c(2,0,1))
r16 <- arima(xiaomi_dec_ran, order = c(2,0,3))
r17 <- arima(xiaomi_dec_ran, order = c(1,0,2))
r18 <- arima(xiaomi_dec_ran, order = c(3,0,2))
r19 <- arima(xiaomi_dec_ran, order = c(2,0,2), include.mean = FALSE)
AIC(r15)
AIC(r16)
AIC(r17)
AIC(r18)
AIC(r19)
AIC(r12)

r110 <- arima(xiaomi_dec_ran, order = c(2,0,0))
r111 <- arima(xiaomi_dec_ran, order = c(3,0,1))
r112 <- arima(xiaomi_dec_ran, order = c(1,0,1))
r113 <- arima(xiaomi_dec_ran, order = c(2,0,1), include.mean = FALSE)
AIC(r110)
AIC(r111)
AIC(r112)
AIC(r113)
AIC(r15)

r114 <- arima(xiaomi_dec_ran, order = c(2,0,0), include.mean = FALSE)
r115 <- arima(xiaomi_dec_ran, order = c(1,0,1), include.mean = FALSE)
r116 <- arima(xiaomi_dec_ran, order = c(3,0,1), include.mean = FALSE)
AIC(r114)
AIC(r115)
AIC(r116)
AIC(r113)

checkresiduals(r113)
xiaomi[, Model4Fitted := xiaomi_dec_tre + xiaomi_dec_sea + fitted(r113)]
tsdisplay(ts(xiaomi$sold_count-xiaomi$Model4Fitted))
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model4Fitted, color = "fitted"))

# tsdisplay(xiaomi_dec_ran)
# plot(xiaomi_ts_dec)
# summary(ur.kpss(xiaomi_ts_dec$random))
# ?decompose
# g11 <- auto.arima(xiaomi_ts_dec$random, trace = TRUE)

# FORECASTING ----
xiaomi_test_comp <- ArrangeTestData(6676673)
xiaomi_test <- ArrangeTestData(6676673)
xiaomi_test[,price_lag1 := shift(price,1)]
xiaomi_test[,basket_count_lag2 := shift(basket_count,2)]
xiaomi_test[,category_favored_lag2 := shift(category_favored,2)]
xiaomi_test[,category_sold_lag2 := shift(category_sold,2)]
xiaomi_test[,category_visits_lag2 := shift(category_visits,2)]
xiaomi_test <- xiaomi_test[sold_count>=low & sold_count<=up,]
xiaomi_test <- xiaomi_test[event_date <= ydm("2021-11-06")]
test_dates=seq(ydm("2021-28-05"),ydm("2021-11-06"),by='day')

# Model 1----
fmla='sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_favored_lag2'
xiaomi_test[, 'Model1' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- xiaomi_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residual, order = c(1,0,1), include.mean = FALSE)
  forecasted=predict(fitted_lm,xiaomi_test[event_date == test_dates[i],])
  xiaomi_test[nrow(xiaomi_test)-length(test_dates)+i, Model1 := (forecasted+forecast(rm,h=2)$mean[2])]
}

# Prediction Script 1----
fmla='sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_favored_lag2'
current_date = "2021-06-24"
past_data <- xiaomi_test[event_date<=current_date,]
fitted_lm=lm(as.formula(fmla),past_data)
rm <- arima(fitted_lm$residual, order = c(1,0,1), include.mean = FALSE)
trend = 398
month = 'Jun'
price_lag1 = 123
wday = 'Sat'
basket_count_lag2 = 1012
category_sold_lag2 = 4402
category_favored_lag2 = 22111
pred <- data.frame(trend, month, price_lag1, wday, basket_count_lag2, category_sold_lag2, category_favored_lag2)
pred_fit <- predict(fitted_lm, pred)
prediction <- pred_fit + forecast(rm,h=2)$mean[2]
prediction
tail(xiaomi_test,1)

# Model 2 ----
fmla='sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_favored_lag2'
xiaomi_test[, 'Model2' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- xiaomi_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residuals, order = c(3,0,3), include.mean = FALSE)
  forecasted=predict(fitted_lm,xiaomi_test[event_date == test_dates[i],])
  xiaomi_test[nrow(xiaomi_test)-length(test_dates)+i, Model2 := (forecasted+forecast(rm,h=2)$mean[2])]
}

# Prediction Script 2----
fmla='sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_favored_lag2'
current_date = "2021-06-24"
past_data <- xiaomi_test[event_date<=current_date,]
fitted_lm=lm(as.formula(fmla),past_data)
rm <- arima(random2, order = c(3,0,3), include.mean = FALSE)
trend = 398
month = 'Jun'
price_lag1 = 123
wday = 'Sat'
basket_count_lag2 = 1012
category_sold_lag2 = 4402
category_favored_lag2 = 22111
pred <- data.frame(trend, month, price_lag1, wday, basket_count_lag2, category_sold_lag2, category_favored_lag2)
pred_fit <- predict(fitted_lm, pred)
prediction <- pred_fit + forecast(rm,h=2)$mean[2]
prediction

# Model 3 ----
fmla = 'sold_count ~ trend + month + wday'
xiaomi_test[, 'Model3' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- xiaomi_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residual, order = c(2,0,1), include.mean = FALSE)
  forecasted=predict(fitted_lm,xiaomi_test[event_date == test_dates[i],])
  xiaomi_test[nrow(xiaomi_test)-length(test_dates)+i, Model3 := (forecasted+forecast(rm,h=2)$mean[2])]
}

# Model 4 ----
fmla = 'sold_count ~ trend + month + wday'
xiaomi_test[, 'Model4' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- xiaomi_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residual, order = c(1,0,0), include.mean = FALSE)
  forecasted=predict(fitted_lm,xiaomi_test[event_date == test_dates[i],])
  xiaomi_test[nrow(xiaomi_test)-length(test_dates)+i, Model4 := (forecasted+forecast(rm,h=2)$mean[2])]
}

# Model 5 ----
xiaomi_test[, Model5 := NULL]
for(i in 1:length(test_dates)){
  current_date <- test_dates[i] - 2
  past_data <- xiaomi_test[event_date<=current_date]
  xiaomi_sarima_test <- arima(ts(past_data$sold_count), c(3,1,1))
  fore <- predict(xiaomi_sarima_test, n.ahead = 2)
  xiaomi_test[event_date == test_dates[i], Model5 := fore$pred[2]]
}

# Prediction Script ----
xiaomi_sarima_test <- arima(ts(xiaomi_test$sold_count), c(3,1,1))
predict(xiaomi_sarima_test, n.ahead = 2)

# Model 6 ----
fore <- predict(xiaomi_sarimax, n.ahead = 27, newxreg = tail(xiaomi_test[,c(17,18,20)],27)) #Order = (1,0,1) + Additional regressors
for(i in 1:length(test_dates)){
  xiaomi_test[event_date == test_dates[i], Model6 := fore$pred[i]]
}

# Model 7 ----
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- xiaomi_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 28)
  dec <- decompose(series)
  
  tre <- dec$trend
  ran <- dec$random
  sea <- dec$seasonal
  
  trend_pred <- holt(tre[15:(344+i)],16)
  sea_pred <- sea[length(sea)-26]
  rm <- arima(ran, order = c(2,0,1), include.mean = FALSE)
  ran_pred <- predict(rm,n.ahead = 16)
  xiaomi_test[event_date == test_dates[i], Model7 := trend_pred$mean[16]+sea_pred+ran_pred$pred[16]]
}

# Prediction Script Decomposition ----
current_date <- "2021-06-24"
past_data <- xiaomi_test[event_date <= current_date,]
series <- ts(past_data$sold_count, frequency = 28)
dec <- decompose(series)
tre <- dec$trend
ran <- dec$random
sea <- dec$seasonal
trend_pred <- holt(tre[15:(length(series)-14)],16)
sea_pred <- sea[length(sea)-26]
rm <- arima(ran, order = c(2,0,1), include.mean = FALSE)
ran_pred <- predict(rm,n.ahead = 16)
trend_pred$mean[16]+sea_pred+ran_pred$pred[16]

# Model 8 ----
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- xiaomi_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 28)
  dec <- decompose(series)
  
  tre <- dec$trend
  ran <- dec$random
  sea <- dec$seasonal
  
  trend_pred <- holt(tre[15:(344+i)],16)
  sea_pred <- sea[length(sea)-26]
  rm <- Arima(ran, model = r_auto)
  ran_pred <- predict(rm,n.ahead = 16)
  xiaomi_test[event_date == test_dates[i], Model8 := trend_pred$mean[16]+sea_pred+ran_pred$pred[16]]
}

# Prediction Script Decomposition -----
current_date <- "2021-06-24"
past_data <- xiaomi_test[event_date <= current_date,]
series <- ts(past_data$sold_count, frequency = 28)
dec <- decompose(series)
tre <- dec$trend
ran <- dec$random
sea <- dec$seasonal
trend_pred <- holt(tre[15:(length(series)-14)],16)
sea_pred <- sea[length(sea)-27+1]
rm <- Arima(ran, model = r_auto)
ran_pred <- predict(rm,n.ahead = 16)
trend_pred$mean[16]+sea_pred+ran_pred$pred[16]

# Naive ----

for(i in 1:length(test_dates)){
  date=test_dates[i]-2
  n <- xiaomi_test[event_date == date, sold_count]
  xiaomi_test[event_date == test_dates[i], Naive := n]
}

# Evaluation ----
perf <- tail(xiaomi_test,length(test_dates))
alt1 <- accu(perf$sold_count,as.vector(perf$Model1))
alt2 <- accu(perf$sold_count,as.vector(perf$Model2))
alt3 <- accu(perf$sold_count,as.vector(perf$Model3))
alt4 <- accu(perf$sold_count,as.vector(perf$Model4))
alt5 <- accu(perf$sold_count,as.vector(perf$Model5))
alt6 <- accu(perf$sold_count,as.vector(perf$Model6))
alt7 <- accu(perf$sold_count,as.vector(perf$Model7))
alt8 <- accu(perf$sold_count,as.vector(perf$Model8))
alt_n <- accu(perf$sold_count,as.vector(perf$Naive))

model_comparison = data.frame(alt1)
model_comparison[2,] <- alt2
model_comparison[3,] <- alt3
model_comparison[4,] <- alt4
model_comparison[5,] <- alt5
model_comparison[6,] <- alt6
model_comparison[7,] <- alt7
model_comparison[8,] <- alt8
model_comparison[9,] <- alt_n
model_comparison

eval = data.frame(c("Alternative 1", alt1))
colnames(eval)[1] <- "Model"
eval[2,] <- c("Alternative 2", alt2)
eval[3,] <- c( "Alternative 3", alt5)
eval[4,] <- c("Alternative 4", alt7)
eval[5,] <- c("Naive", alt_n)
eval
