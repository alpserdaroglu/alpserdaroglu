source("Functions.r")

# Fakir ----
dummy <- ArrangeTrainData(7061886)

head(fakir)
tail(fakir)

fakir <- fakir[order(event_date),]
skim(fakir)
lapply(fakir, function(x){ length(which(x==0))/length(x)})

# Cross-correlations with lag 2. Data from two days before will available when we make our predictions. Only price data
# will be available with lag 1.
auto <- c()
for(i in 3:13){
  x <- ccf(fakir[,4], fakir[,..i], plot = FALSE)
  auto[i-2] <- x[2]$acf
}
auto

ggplot(fakir, aes(x = event_date)) +
  geom_line(aes(y = price))
ggplot(fakir, aes(x = event_date)) +
  geom_line(aes(y = basket_count))
ggplot(fakir, aes(x = event_date)) +
  geom_line(aes(y = category_sold))
ggplot(fakir, aes(x = event_date)) +
  geom_line(aes(y = category_visits))
ggplot(fakir, aes(x = event_date)) +
  geom_line(aes(y = category_favored))

fakir[,price_lag1 := shift(price,1)]
fakir[,basket_count_lag2 := shift(basket_count,2)]
fakir[,category_favored_lag2 := shift(category_favored,2)]
fakir[,category_sold_lag2 := shift(category_sold,2)]
fakir[,category_visits_lag2 := shift(category_visits,2)]

ggplot(fakir) +
  geom_boxplot(aes(y = sold_count))
ggplot(fakir) +
  geom_histogram(aes(x = sold_count))
ggplot(fakir, aes(x = event_date)) +
  geom_line(aes(y = sold_count)) # variance constant, data not stationatry (trend + season effects)

quant <- quantile(fakir$sold_count,probs=c(0.25,0.75), na.rm = TRUE)
iqr <- IQR(fakir$sold_count)
up <-  quant[2]+1.5*iqr
low <- quant[1]-1.5*iqr 
fakir_with_outliers <- fakir
fakir_with_outliers[sold_count<=low | sold_count>=up,]
fakir <- fakir[sold_count>=low & sold_count<=up,]

acf(fakir$sold_count, lag.max = 40) 
pacf(fakir$sold_count, lag.max = 40)
ccf(fakir$sold_count,fakir$basket_count)
ccf(fakir$sold_count,fakir$category_favored)

# Dynamic Regression -> Trend Season Other + ARIMA on Errors ----
correl <- cor(fakir[,c(4,17:21)])
ggcorrplot(correl, hc.order = TRUE, type = 'lower')
ggpairs(fakir[,c(4,17:21)]) # visit count lag, price, basket lag, cat sold lag, favored_count lag, cat favored lag

m11 <- lm(sold_count~trend+month, fakir)
summary(m11)
AIC(m11)
checkresiduals(m11) # residuals not good

m12 <- lm(sold_count ~ trend + month + wday, fakir)
summary(m12)
AIC(m12) #AIC did not improve, adj r2 not improved, regression with trend and wday also not good

m13 <- lm(sold_count ~ trend + month + price_lag1, fakir)
summary(m13)
AIC(m13)
checkresiduals(m13)

m13b <- lm(sold_count ~ trend + month + wday + price_lag1, fakir)
summary(m13b)
AIC(m13b)
checkresiduals(m13b)

# m14 <- lm(sold_count ~ trend + month + price + basket_count + category_favored, fakir)
# summary(m14)
# AIC(m14)
# checkresiduals(m14)

m14b <- lm(sold_count ~ trend + month + price_lag1 + basket_count_lag2 + category_sold_lag2 + wday, fakir)
summary(m14b)
AIC(m14b)
checkresiduals(m14b)

m14c <- lm(sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_visits_lag2 + category_favored_lag2, fakir)
summary(m14c)
AIC(m14c)
checkresiduals(m14c)

# Find the best arima m14c ----
random1 <- ts(m14c$residuals, frequency = 32)
summary(ur.kpss(random1, use.lag = 30))

#random is stationary, begin arima check pacf and acf
acf(m14c$residuals, lag.max = 40)
pacf(m14c$residuals, lag.max = 40)
tsdisplay(random1)

d21 <- arima(random1, order = c(0,0,0))
d22 <- arima(random1, order = c(2,0,2)) 
d23 <- arima(random1, order = c(1,0,0)) # best
d24 <- arima(random1, order = c(0,0,1))
AIC(d21)
AIC(d22) 
AIC(d23) # best
AIC(d24)

d25 <- arima(random1, order = c(2,0,0))
d26 <- arima(random1, order = c(1,0,1))
d27 <- arima(random1, order = c(1,0,0), include.mean = FALSE) #best winner
AIC(d25)
AIC(d26)
AIC(d27) # winner

d28 <- arima(random1, order = c(0,0,0), include.mean = FALSE)
d29 <- arima(random1, order = c(2,0,0), include.mean = FALSE)
d210 <- arima(random1, order = c(1,0,1), include.mean = FALSE)
AIC(d28)
AIC(d29)
AIC(d210)

autoarima1 <- auto.arima(random1, trace = TRUE)

checkresiduals(d27)
alt1_fitted <- fitted(d27) + m14c$fitted.values
fakir[,Model1Fitted := c(NA,NA,alt1_fitted)]
tsdisplay(ts(fakir$sold_count-fakir$Model1Fitted))
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model1Fitted, color = "fitted"))

# Find the best arima m11 ----
random2 <- ts(m11$residuals, frequency = 21)
summary(ur.kpss(random2, use.lag = 30))

#random is stationary, begin arima check pacf and acf
acf(m11$residuals, lag.max = 80)
pacf(m11$residuals, lag.max = 40)
tsdisplay(random2)

e11 <- arima(random2, order = c(0,0,0))
e12 <- arima(random2, order = c(2,0,2)) 
e13 <- arima(random2, order = c(1,0,0)) # best
e14 <- arima(random2, order = c(0,0,1))
AIC(e11)
AIC(e12)
AIC(e13)
AIC(e14)

e15 <- arima(random2, order = c(2,0,0))
e16 <- arima(random2, order = c(1,0,1))
e17 <- arima(random2, order = c(1,0,0), include.mean = FALSE) #best
AIC(e15)
AIC(e16)
AIC(e17) # best

e18 <- arima(random2, order = c(0,0,0), include.mean = FALSE)
e19 <- arima(random2, order = c(2,0,0), include.mean = FALSE)
e110 <- arima(random2, order = c(1,0,1), include.mean = FALSE) # best winner
AIC(e18)
AIC(e19)
AIC(e110) # winner

e111 <- arima(random2, order = c(1,0,2), include.mean = FALSE)
e112 <- arima(random2, order = c(2,0,1), include.mean = FALSE) 
e113 <- arima(random2, order = c(0,0,1), include.mean = FALSE)
AIC(e111)
AIC(e112)
AIC(e113)

autoarima2 <- auto.arima(random2, trace = TRUE)
summary(e110)
checkresiduals(e110)
alt2_fitted <- fitted(e110) + m11$fitted.values
fakir[,Model2Fitted := alt2_fitted]
tsdisplay(ts(fakir$sold_count-fakir$Model2Fitted))
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model2Fitted, color = "fitted"))

checkresiduals(autoarima2)
alt3_fitted <- fitted(autoarima2) + m11$fitted.values
fakir[,Model3Fitted := alt3_fitted]
tsdisplay(ts(fakir$sold_count-fakir$Model3Fitted))
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model2Fitted, color = "fitted"))

# Sarimax ----
fakir_ts <- ts(fakir$sold_count, frequency = 21)
acf(fakir$sold_count, lag.max = 50)
pacf(fakir$sold_count, lag.max = 50)

fakir_sarima <- auto.arima(fakir_ts, trace = TRUE, seasonal = TRUE)
summary(fakir_sarima2)
AIC(fakir_sarima)

checkresiduals(fakir_sarima)
tsdisplay(fakir_sarima$residuals)
fakir[,Model4Fitted := fakir_sarima$fitted]
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model4Fitted, color = "fitted"))


fakir_ts <- ts(fakir$sold_count)
fakir_sarima2 <- auto.arima(fakir_ts, trace = TRUE, seasonal = TRUE)

checkresiduals(fakir_sarima2)
tsdisplay(fakir_sarima2$residuals)
fakir[,Model5Fitted := fakir_sarima2$fitted]
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model5Fitted, color = "fitted"))

fakir_ts <- ts(fakir$sold_count, frequency = 21)
fakir_sarimax <- auto.arima(fakir_ts[3:341],
                             xreg =matrix(c(fakir$price[3:nrow(fakir)],
                                            fakir$basket_count_lag2[3:nrow(fakir)],
                                            fakir$category_sold_lag2[3:nrow(fakir)]), nrow = nrow(fakir)-2),
                             trace = TRUE, seasonal = TRUE)
AIC(fakir_sarimax)
y <- data.frame(fakir_sarimax$x, fakir_sarimax$fitted)
ggplot(y, aes(x=fakir_sarimax.x )) +
  geom_point(aes( y = fakir_sarimax.fitted)) +
  geom_abline(slope = 1, intercept = 0)

summary(ur.kpss(fakir_ts, use.lag = 28))

#Model without regressors: ARIMA ar(3) + mean 4799.68 /.518 (sarima)
#Model with regressors: ARIMA ar(2) + + d(1) + ma(1) with mean 4619.74 but again without regressors (sarimax)

# Decomposition ----
acf(fakir$sold_count, lag.max = 40)

fakir_ts <- ts(fakir$sold_count, frequency = 21)
tsdisplay(fakir_ts)
fakir_ts_dec <- decompose(fakir_ts)
summary(ur.kpss(fakir_ts_dec$random))

fakir_dec_tre <- fakir_ts_dec$trend
fakir_dec_ran <- fakir_ts_dec$random
fakir_dec_sea <- fakir_ts_dec$seasonal

holt(fakir_dec_tre[11:331],15)
r_auto <- auto.arima(fakir_dec_ran, trace = TRUE)

r11 <- arima(fakir_dec_ran, order = c(0,0,0))
r12 <- arima(fakir_dec_ran, order = c(2,0,2)) # best
r13 <- arima(fakir_dec_ran, order = c(1,0,0))  
r14 <- arima(fakir_dec_ran, order = c(0,0,1))
AIC(r11)
AIC(r12)
AIC(r13)
AIC(r14)

r15 <- arima(fakir_dec_ran, order = c(2,0,1))
r16 <- arima(fakir_dec_ran, order = c(2,0,3))
r17 <- arima(fakir_dec_ran, order = c(1,0,2))
r18 <- arima(fakir_dec_ran, order = c(3,0,2))
r19 <- arima(fakir_dec_ran, order = c(2,0,2), include.mean = FALSE) # best winner
AIC(r15)
AIC(r16)
AIC(r17)
AIC(r18)
AIC(r19)
AIC(r12)

r110 <- arima(fakir_dec_ran, order = c(2,0,1), include.mean = FALSE)
r111 <- arima(fakir_dec_ran, order = c(3,0,2), include.mean = FALSE)
r112 <- arima(fakir_dec_ran, order = c(1,0,2), include.mean = FALSE)
r113 <- arima(fakir_dec_ran, order = c(2,0,3), include.mean = FALSE)
AIC(r110)
AIC(r111)
AIC(r112)
AIC(r113)


# tsdisplay(fakir_dec_ran)
# plot(fakir_ts_dec)
# summary(ur.kpss(fakir_ts_dec$random))
# ?decompose
# g11 <- auto.arima(fakir_ts_dec$random, trace = TRUE)

# FORECASTING ----

fakir_test <- ArrangeTestData(7061886)
fakir_test[,price_lag1 := shift(price,1)]
fakir_test[,basket_count_lag2 := shift(basket_count,2)]
fakir_test[,category_favored_lag2 := shift(category_favored,2)]
fakir_test[,category_sold_lag2 := shift(category_sold,2)]
fakir_test[,category_visits_lag2 := shift(category_visits,2)]
fakir_test <- fakir_test[sold_count>=low & sold_count<=up,]
fakir_test <- fakir_test[event_date <= ydm("2021-11-06")]

test_dates=seq(ydm("2021-28-05"),ydm("2021-11-06"),by='day')

# Model 1----
fmla='sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_favored_lag2'
fakir_test[, 'Model1' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- fakir_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residual, order = c(1,0,0), include.mean = FALSE)
  forecasted=predict(fitted_lm,fakir_test[event_date == test_dates[i],])
  # fore[i] <- forecasted+forecast(rm,h=1)$mean
  fakir_test[nrow(fakir_test)-length(test_dates)+i, Model1 := (forecasted+forecast(rm,h=2)$mean[2])]
}

# Model 2 ----
fmla='sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_favored_lag2'
fakir_test[, 'Model2' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- fakir_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- Arima(fitted_lm$residual, model = autoarima1)
  forecasted=predict(fitted_lm,fakir_test[event_date == test_dates[i],])
  fakir_test[nrow(fakir_test)-length(test_dates)+i, Model2 := (forecasted+forecast(rm,h=2)$mean[2])]
}

# Model 3 ----
fmla = 'sold_count~trend+month'
fakir_test[, 'Model3' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- fakir_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residuals, order = c(1,0,1), include.mean = FALSE)
  forecasted=predict(fitted_lm,fakir_test[event_date == test_dates[i],])
  fakir_test[nrow(fakir_test)-length(test_dates)+i, Model3 := (forecasted+forecast(rm,h=2)$mean[2])]
}

# Prediction Script 3----
fmla = 'sold_count~trend+month'
current_date = "2021-06-24"
past_data <- fakir_test[event_date<=current_date,]
fitted_lm=lm(as.formula(fmla),past_data)
rm <- arima(fitted_lm$residual, order = c(1,0,1), include.mean = FALSE)
trend = 398
month = 'Jun'
price_lag1 = 330
wday = 'Sat'
basket_count_lag2 = 27
category_sold_lag2 = 587
category_favored_lag2 = 4055
pred <- data.frame(trend, month, price_lag1, wday, basket_count_lag2, category_sold_lag2, category_favored_lag2)
pred_fit <- predict(fitted_lm, pred)
prediction <- pred_fit + forecast(rm,h=2)$mean[2]
prediction
tail(fakir_test,1)

# Model 4 ----
fmla = 'sold_count ~ trend + month'
fakir_test[, 'Model4' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- fakir_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- Arima(fitted_lm$residual, model = autoarima2)
  forecasted=predict(fitted_lm,fakir_test[event_date == test_dates[i],])
  fakir_test[nrow(fakir_test)-length(test_dates)+i, Model4 := (forecasted+forecast(rm,h=2)$mean[2])]
}

#Prediction Script 4 ----
fmla = 'sold_count ~ trend + month'
current_date = "2021-06-24"
past_data <- fakir_test[event_date<=current_date,]
fitted_lm=lm(as.formula(fmla),past_data)
rm <-  Arima(fitted_lm$residual, model = autoarima2)
trend = 398
month = 'Jun'
price_lag1 = 330
wday = 'Sat'
basket_count_lag2 = 27
category_sold_lag2 = 587
category_favored_lag2 = 4055
pred <- data.frame(trend, month, price_lag1, wday, basket_count_lag2, category_sold_lag2, category_favored_lag2)
pred_fit <- predict(fitted_lm, pred)
prediction <- pred_fit + forecast(rm,h=2)$mean[2]
prediction

# Model 5 ----

for(i in 1:length(test_dates)){
  current_date <- test_dates[i] - 2
  past_data <- fakir_test[event_date<=current_date]
  fakir_sarima_test <- Arima(ts(past_data$sold_count, frequency = 21), model = fakir_sarima)
  fore <- predict(fakir_sarima_test, n.ahead = 2)
  fakir_test[event_date == test_dates[i], Model5 := fore$pred[2]]
}

current_date = "2021-06-24"
past_data <- fakir_test[event_date<=current_date,]
rm <-  Arima(ts(past_data$sold_count, frequency = 21), order = c(1,1,1), seasonal = c(2,0,0))
fore <- predict(rm, n.ahead = 2)
fore$pred[2]

# Model 6 ----
for(i in 1:length(test_dates)){
  current_date <- test_dates[i] - 2
  past_data <- fakir_test[event_date<=current_date]
  fakir_sarima_test2 <- Arima(ts(past_data$sold_count), model = fakir_sarima2)
  fore <- predict(fakir_sarima_test2, n.ahead = 2)
  fakir_test[event_date == test_dates[i], Model6 := fore$pred[2]]
}

current_date <- "2021-06-24"
past_data <- fakir_test[event_date<=current_date]
fakir_sarima_test2 <- Arima(ts(past_data$sold_count), model = fakir_sarima2)
fore <- predict(fakir_sarima_test2, n.ahead = 2)
fore

# Model 7 ----
fore <- predict(fakir_sarimax, n.ahead = 18, newxreg = tail(fakir_test[,c(17,18,20)],18))
for(i in 1:length(test_dates)){
  fakir_test[event_date == test_dates[i], Model7 := fore$pred[i]]
}

# Model 8 ----
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- fakir_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 21)
  dec <- decompose(series)
  
  tre <- dec$trend
  ran <- dec$random
  sea <- dec$seasonal
  
  trend_pred <- holt(tre[11:(329+i)],12)
  sea_pred <- sea[length(sea)-19]
  rm <- arima(ran, order = c(2,0,2), include.mean = FALSE)
  ran_pred <- predict(rm,n.ahead = 12)
  fakir_test[event_date == test_dates[i], Model8 := trend_pred$mean[12]+sea_pred+ran_pred$pred[12]]
}

# Model 9 ----
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- fakir_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 21)
  dec <- decompose(series)
  
  tre <- dec$trend
  ran <- dec$random
  sea <- dec$seasonal
  
  trend_pred <- holt(tre[11:(329+i)],12)
  sea_pred <- sea[length(sea)-19]
  rm <- Arima(ran, model = r_auto)
  ran_pred <- predict(rm,n.ahead = 12)
  fakir_test[event_date == test_dates[i], Model9 := trend_pred$mean[12]+sea_pred+ran_pred$pred[12]]
}

# Naive ----

for(i in 1:length(test_dates)){
  date=test_dates[i]-2
  n <- fakir_test[event_date == date, sold_count]
  fakir_test[event_date == test_dates[i], Naive := n]
}

# Evauation
perf <- tail(fakir_test,length(test_dates))
alt1 <- accu(perf$sold_count,as.vector(perf$Model1))
alt2 <- accu(perf$sold_count,as.vector(perf$Model2))
alt3 <- accu(perf$sold_count,as.vector(perf$Model3))
alt4 <- accu(perf$sold_count,as.vector(perf$Model4))
alt5 <- accu(perf$sold_count,as.vector(perf$Model5))
alt6 <- accu(perf$sold_count,as.vector(perf$Model6))
alt7 <- accu(perf$sold_count,as.vector(perf$Model7))
alt8 <- accu(perf$sold_count,as.vector(perf$Model8))
alt9 <- accu(perf$sold_count,as.vector(perf$Model9))
alt_n <- accu(perf$sold_count,as.vector(perf$Naive))

model_comparison = data.frame(alt1)
model_comparison[2,] <- alt2
model_comparison[3,] <- alt3
model_comparison[4,] <- alt4
model_comparison[5,] <- alt5
model_comparison[6,] <- alt6
model_comparison[7,] <- alt7
model_comparison[8,] <- alt8
model_comparison[9,] <- alt9
model_comparison[10,] <- alt_n
model_comparison

eval = data.frame(c("Alternative 1", alt1))
colnames(eval)[1] <- "Model"
eval[2,] <- c("Alternative 2", alt3)
eval[3,] <- c( "Alternative 3", alt4)
eval[4,] <- c("Alternative 4", alt5)
eval[5,] <- c("Alternative 5", alt6)
eval[6,] <- c("Naive", alt_n)
eval

#####
#Differencing WIP
# fakir_ts <- ts(fakir$sold_count)
# tsdisplay(fakir_ts)
# 
# fakir_ts_diff32 <- diff(fakir_ts, lag=32)
# tsdisplay(fakir_ts_diff32)
# 
# m15 <- lm(sold_count ~ price + basket_count_lag1 + category_favored_lag1, fakir)
# summary(m15)
# AIC(m15)
# checkresiduals(m15)
# acf(m15$residuals, lag.max = 40)
# m15_res <- ts(m15$residuals, freq = 32)
# summary(ur.kpss(m15_res))
# m15_res_diff <- diff(m15_res)
# summary(ur.kpss(m15_res_diff))
# 
# acf(m15_res_diff, lag.max = 40)
# pacf(m15_res_diff, lag.max = 40)
# 
# f11 <- arima(m15_res_diff, c(0,0,0))
# f12 <- arima(m15_res_diff, c(0,0,1))
# f13 <- arima(m15_res_diff, c(1,0,0))
# f14 <- arima(m15_res_diff, c(2,0,2))
# AIC(f11)
# AIC(f12)
# AIC(f13)
# AIC(f14) #best
# 
# f15 <- arima(m15_res_diff, c(1,0,2))
# f16 <- arima(m15_res_diff, c(3,0,2))
# f17 <- arima(m15_res_diff, c(2,0,1))
# f18 <- arima(m15_res_diff, c(2,0,3))
# f19 <- arima(m15_res_diff, c(2,0,3), include.mean = FALSE)
# AIC(f15)
# AIC(f16)
# AIC(f17) #best
# AIC(f18)
# AIC(f19)
# 
# f110 <- arima(m15_res_diff, c(1,0,1))
# f111 <- arima(m15_res_diff, c(3,0,1))
# f112 <- arima(m15_res_diff, c(2,0,0))
# f113 <- arima(m15_res_diff, c(2,0,1), include.mean = FALSE)
# AIC(f110)
# AIC(f111)
# AIC(f112) 
# AIC(f113) #best
# 
# #f113 <- arima(m15_res_diff, c(2,0,1), include.mean = FALSE)
# f114 <- arima(m15_res_diff, c(3,0,1), include.mean = FALSE)
# f115 <- arima(m15_res_diff, c(2,0,2), include.mean = FALSE)
# f116 <- arima(m15_res_diff, c(2,0,0), include.mean = FALSE)
# AIC(f114)
# AIC(f115)
# AIC(f116) #best
# 
# x <- auto.arima(m15_res_diff, trace = TRUE)
# y <- data.frame(fakir_sarima$x, fakir_sarima$fitted)
# ggplot(y, aes(x=fakir_sarima.x )) +
#   geom_point(aes( y = fakir_sarima.fitted)) +
#   geom_abline(slope = 1, intercept = 0)


