source("Functions.r")

# Mont ----
mont <- ArrangeTrainData(48740784)

head(mont)
tail(mont)

mont <- mont[order(event_date),]
dummy <- mont[!is.na(price)]
# mont[is.na(price), sold_count := 0]
# mont[is.na(price), price := 0]

skim(dummy)
lapply(dummy, function(x){ length(which(x==0))/length(x)})

auto <- c()
for(i in 3:13){
  x <- ccf(mont[,4], mont[,..i], plot = FALSE)
  auto[i-2] <- x[2]$acf
}
auto

ggplot(mont, aes(x = sold_count)) +
  geom_point(aes(y = price))
ggplot(mont, aes(x = event_date)) +
  geom_line(aes(y = basket_count))
ggplot(mont, aes(x = event_date)) +
  geom_line(aes(y = category_sold))
ggplot(mont, aes(x = event_date)) +
  geom_line(aes(y = category_visits))
ggplot(mont, aes(x = event_date)) +
  geom_line(aes(y = category_favored))

mont[,price_lag1 := shift(price,1)]
mont[,basket_count_lag2 := shift(basket_count,2)]
mont[,category_favored_lag2 := shift(category_favored,2)]
mont[,category_sold_lag2 := shift(category_sold,2)]
mont[,category_visits_lag2 := shift(category_visits,2)]

ggplot(mont) +
  geom_boxplot(aes(y = sold_count))
ggplot(mont) +
  geom_histogram(aes(x = sold_count))
ggplot(mont, aes(x = event_date)) +
  geom_col(aes(y = sold_count)) # variance constant, data not stationatry (trend + season effects)

mont_with_na <- mont
mont <- mont[!is.na(price)]

quant <- quantile(mont$sold_count,probs=c(0.25,0.75), na.rm = TRUE)
iqr <- IQR(mont$sold_count)
up <-  quant[2]+1.5*iqr
low <- quant[1]-1.5*iqr 
mont_with_outliers <- mont
mont_with_outliers[sold_count<=low | sold_count>=up,]
mont <- mont[sold_count>=low & sold_count<=up,]

acf(mont$sold_count, lag.max = 40) 
pacf(mont$sold_count, lag.max = 40)
ccf(mont$sold_count,mont$basket_count)
ccf(mont$sold_count,mont$category_favored)
ccf(mont$sold_count,mont$category_sold)
ccf(mont$sold_count,mont$category_visits)
ccf(mont$sold_count,mont$price)

# Dynamic Regression -> Trend Season Other + ARIMA on Errors ----
correl <- cor(mont[,c(4,17:21)])
ggcorrplot(correl, hc.order = TRUE, type = 'lower')
ggpairs(mont[,c(4,17:21)]) # visit count lag, price, basket lag, cat sold lag, favored_count lag, cat favored lag

m11 <- lm(sold_count~month+wday, mont)
summary(m11)
AIC(m11)
checkresiduals(m11) # residuals not good
mont[, Model1Fitted := m11$fitted.values]
tsdisplay(ts(mont$sold_count-mont$Model1Fitted))
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model1Fitted, color = "fitted"))

m12 <- lm(sold_count ~ trend + month + wday, mont)
summary(m12)
AIC(m12)

m13 <- lm(sold_count ~ trend + month + price_lag1, mont)
summary(m13)
AIC(m13)
checkresiduals(m13)

m13b <- lm(sold_count ~ trend + month + wday + price_lag1, mont)
summary(m13b)
AIC(m13b)
checkresiduals(m13b)

m14b <- lm(sold_count ~ trend + month + price_lag1 + basket_count_lag2 + category_sold_lag2 + wday, mont)
summary(m14b)
AIC(m14b)
checkresiduals(m14b)

m14c <- lm(sold_count ~ trend + month + price_lag1 + wday + basket_count_lag2 + category_sold_lag2 + category_visits_lag2 + category_favored_lag2, mont)
summary(m14c)
AIC(m14c)
checkresiduals(m14c)

# Find the best arima m11 ----
random1 <- ts(m11$residuals)
summary(ur.kpss(random1, use.lag = 30))

mont_ts <- ts(mont$sold_count)
summary(ur.kpss(mont_ts))

#random is stationary, begin arima check pacf and acf
acf(m11$residuals, lag.max = 40)
pacf(m11$residuals, lag.max = 40)
tsdisplay(random1)

d21 <- arima(random1, order = c(0,0,0))
d22 <- arima(random1, order = c(2,0,2)) 
d23 <- arima(random1, order = c(1,0,0)) # best
d24 <- arima(random1, order = c(0,0,1))
AIC(d21)
AIC(d22) 
AIC(d23) # best
AIC(d24)

d25 <- arima(random1, order = c(1,0,1))
d26 <- arima(random1, order = c(0,0,2))
d27 <- arima(random1, order = c(0,0,0)) 
d28 <- arima(random1, order = c(0,0,0), include.mean = FALSE) #best winner
AIC(d25)
AIC(d26)
AIC(d27)
AIC(d28)

d29 <- arima(random1, order = c(1,0,2))
d30 <- arima(random1, order = c(1,0,0))
d31 <- arima(random1, order = c(0,0,1))
d32 <- arima(random1, order = c(2,0,1))
d33 <- arima(random1, order = c(1,0,1), include.mean = FALSE) #best winner
AIC(d29)
AIC(d30)
AIC(d31)
AIC(d32)
AIC(d33)

d34 <- arima(random1, order = c(2,0,2))
d35 <- arima(random1, order = c(1,0,3))
d36 <- arima(random1, order = c(1,0,2), include.mean = FALSE) #best winner
AIC(d34)
AIC(d35)
AIC(d36) # winner!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

d37 <- arima(random1, order = c(1,0,1), include.mean = FALSE)
d38 <- arima(random1, order = c(1,0,3), include.mean = FALSE)
d39 <- arima(random1, order = c(0,0,2), include.mean = FALSE)
d40 <- arima(random1, order = c(2,0,2), include.mean = FALSE)
AIC(d37)
AIC(d38)
AIC(d39)
AIC(d40)

autoarima1 <- auto.arima(random1, trace = TRUE)

checkresiduals(d36)
alt2_fitted <- fitted(d36) + m11$fitted.values
mont[,Model2Fitted := alt2_fitted]
tsdisplay(ts(mont$sold_count-mont$Model2Fitted))
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model2Fitted, color = "fitted"))

checkresiduals(autoarima1)
alt3_fitted <- fitted(autoarima1) + m11$fitted.values
mont[,Model3Fitted := alt3_fitted]
tsdisplay(ts(mont$sold_count-mont$Model3Fitted))
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model3Fitted, color = "fitted"))

# Sarimax ----
mont_ts <- ts(mont$sold_count, frequency = 21)
pacf(mont$sold_count, lag.max = 50)
acf(mont$sold_count, lag.max = 50)

mont_sarimax_eski
mont_sarimax <- auto.arima(mont_ts[3:length(mont_ts)],
                            xreg =matrix(c(mont$basket_count_lag2[3:nrow(mont)],
                                           mont$category_sold_lag2[3:nrow(mont)]), nrow = nrow(mont)-2),
                           trace = TRUE, seasonal = TRUE)

AIC(mont_sarimax)
checkresiduals(mont_sarimax)
mont[,Model4Fitted := c(NA,NA,fitted(mont_sarimax))]
tsdisplay(ts(mont$sold_count-mont$Model4Fitted))
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = sold_count, color = "sold_count"))+
  geom_line(aes(y = Model4Fitted, color = "fitted"))

# Short Interval ----

short <- data[product_content_id == 48740784, ]
short[,price_lag1 := shift(price,1)]
short[,day := wday(ymd(event_date), label = TRUE)]
short <- short[event_date >= "2021-05-09" & event_date <= "2021-06-05", ]
short <- short[price < 0, stockout := 1]
short <- short[price >= 0, stockout := 0]
short <- short[price < 0, price := max(price)]

summary(ur.kpss(ts(short$sold_count)))

ggplot(short) +
  geom_boxplot(aes(y = sold_count))
ggplot(short) +
  geom_histogram(aes(x = sold_count))
ggplot(short, aes(x = event_date)) +
  geom_col(aes(y = sold_count))

short_arima <- auto.arima(short$sold_count, trace = TRUE)

s11 <- arima(short$sold_count, order = c(0,0,0))
s12 <- arima(short$sold_count, order = c(2,0,2)) 
s13 <- arima(short$sold_count, order = c(1,0,0)) # best
s14 <- arima(short$sold_count, order = c(0,0,1))
AIC(s11)
AIC(s12)
AIC(s13) # winner
AIC(s14)

s15 <- arima(short$sold_count, order = c(2,0,0))
s16 <- arima(short$sold_count, order = c(1,0,1))
s17 <- arima(short$sold_count, order = c(1,0,0), include.mean = FALSE) #best
AIC(s15)
AIC(s16)
AIC(s17) # winner

# FORECASTING ----

mont_test <- ArrangeTestData(48740784)
mont_test[,price_lag1 := shift(price,1)]
mont_test[,basket_count_lag2 := shift(basket_count,2)]
mont_test[,category_favored_lag2 := shift(category_favored,2)]
mont_test[,category_sold_lag2 := shift(category_sold,2)]
mont_test[,category_visits_lag2 := shift(category_visits,2)]
mont_test <- mont_test[event_date <= ydm("2021-11-06")]
#mont_test <- mont_test[sold_count>=low & sold_count<=up,]
short_test <- mont_test[event_date >= "2021-05-09"]
#mont_test <- mont_test[!is.na(price)]
#mont_test <- mont_test[price < 0, price := max(price)]
test_dates=seq(ydm("2021-05-06"),ydm("2021-11-06"),by='day')

# Model 1 ----
fmla='sold_count ~ wday + month'
mont_test[, 'Model1' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- mont_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  forecasted=predict(fitted_lm,mont_test[event_date == test_dates[i],])
  mont_test[nrow(mont_test)-length(test_dates)+i, Model1 := forecasted]
}

# Model 2 ----
fmla='sold_count ~ wday + month'
mont_test[, 'Model2' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- mont_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residual, order = c(1,0,2), include.mean = FALSE)
  forecasted=predict(fitted_lm,mont_test[event_date == test_dates[i],])
  mont_test[nrow(mont_test)-length(test_dates)+i, Model2 := (forecasted+forecast(rm,h=2)$mean[2])]
}

current_date <- "2021-06-21"
past_data <- mont_test[event_date<=current_date,]
month = "Jun"
wday = "Wed"
pred <- data.frame(month,wday)
rm <- arima(past_data$sold_count, order = c(1,0,2))
forecast(rm,h=2)$mean + predict(fitted_lm,pred)

# Model 3 ----
fmla='sold_count ~ wday + month'
mont_test[, 'Model3' := NULL]
for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- mont_test[event_date<=current_date,]
  fitted_lm=lm(as.formula(fmla),past_data)
  rm <- arima(fitted_lm$residual, order = c(0,0,1), include.mean = FALSE)
  forecasted=predict(fitted_lm,mont_test[event_date == test_dates[i],])
  mont_test[nrow(mont_test)-length(test_dates)+i, Model3 := (forecasted+forecast(rm,h=2)$mean[2])]
}

current_date <- "2021-06-21"
past_data <- mont_test[event_date<=current_date,]
month = "Jun"
wday = "Wed"
pred <- data.frame(month,wday)
rm <- arima(past_data$sold_count, order = c(0,0,1))
forecast(rm,h=2)$mean + predict(fitted_lm,pred)


# Model 4 ----
fore <- predict(mont_sarimax, n.ahead = 10, newxreg = tail(mont_test[,c(18,20)],10))
for(i in 1:length(test_dates)){
  mont_test[event_date == test_dates[i], Model4 := fore$pred[i]]
}

# basket_count_lag2 - category_sold_lag2
current_date <- "2021-06-21" # en son data point
d <- day(current_date) - day(("2021-06-04"))
today <- c(8, 1098)
target_tomorrow <- c(4, 1024) 
xref = data.frame(c(0,0),c(0,0))
colnames(xref) <- c("basket_count_lag2", "category_sold_lag2")
xref[1,] <- today
xref[2,] <- target_tomorrow
mont_sarimax_test <- arima(ts(mont_test$sold_count), order = c(1,0,0),
                           xreg =matrix(c(mont_test$basket_count_lag2,
                                          mont_test$category_sold_lag2),ncol=2),)
predict(mont_sarimax_test, n.ahead = 2, newxreg = xref)
tail(mont_test,2)
# Model 5 ----

for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- short_test[event_date<=current_date,]
  rm <- arima(past_data$sold_count, order = c(1,0,0))
  forecasted=predict(rm, n.ahead = 2)
  mont_test[nrow(mont_test)-length(test_dates)+i, Model5 := forecasted$pred[2]]
}

current_date <- "2021-06-21"
past_data <- mont_test[event_date<=current_date,]
rm <- arima(past_data$sold_count, order = c(1,0,0))
forecast(rm,h=2)$mean

for(i in 1:length(test_dates)){
  date=test_dates[i]-2
  n <- mont_test[event_date == date, sold_count]
  mont_test[event_date == test_dates[i], Naive := n]
}

# Model Comparison ----
perf <- tail(mont_test,7)
perf <- perf[,Model1 := max(Model1,0)]
perf <- perf[,Model2 := max(Model2,0)]
perf <- perf[,Model3 := max(Model3,0)]
perf <- perf[,Model4 := max(Model4,0)]
perf <- perf[,Model5 := max(Model5,0)]
alt1 <- accu(perf$sold_count,as.vector(perf$Model1))
alt2 <- accu(perf$sold_count,as.vector(perf$Model2))
alt3 <- accu(perf$sold_count,as.vector(perf$Model3))
alt4 <- accu(perf$sold_count,as.vector(perf$Model4))
alt5 <- accu(perf$sold_count,as.vector(perf$Model5))
alt_n <- accu(perf$sold_count,as.vector(perf$Naive))

model_comparison = data.frame(alt1)
model_comparison[2,] <- alt2
model_comparison[3,] <- alt3
model_comparison[4,] <- alt4
model_comparison[5,] <- alt5
model_comparison[6,] <- alt_n
model_comparison

eval = data.frame(alt1)
eval[2,] <- alt2
eval[3,] <- alt3
eval[4,] <- alt4
eval[5,] <- alt_n
eval
